# Book 09 extraction

Source: `09.pdf` (2,130 pages). The PDF contains 10 numbered sections and no embedded book title. “Neurosurgery” in image filenames is a descriptive subject, not a claimed source title.

- `09_book_extraction.json`: 1,000 numbered questions, four options each, 999 source-printed answer keys and explanations. Numeric printed options 1–4 map to A–D, with the printed mapping retained.
- `assets/`: 40 clinical figures and one complete ruled table. All are source-page crops in RGB, including original panels together and all four source edges, with 24 pixels of white padding. Names include book ID, subject, section, question, role, and PDF page.
- `09_assets_contact_sheet.jpg`: visual index of the 41 assets.
- `audit.json` and `independent_audit.json`: source checks and an independent validation pass.
- `09.pdf`: original source for verification.

The supplied PDF ends on Question 1000 before its answer page. Its `correct_answer` and `explanation` are null, and the delivery gate reports this source gap. Explanations are preserved as source prose; option-by-option explanations are not fabricated where the book does not label them. Recurring publisher footer graphics are omitted from clinical assets.
