Neurotrauma in Multiple-Choice Questions (2022): source-grounded extraction.
JSON contains 336 numbered questions across eight chapters, five printed options and answer letters per question.
The book asks for the FALSE answer; these are not true/false questions.
All 19 table images are independent source-page crops with a 24-pixel white perimeter.
The Rotterdam score table spans two PDF pages and was stitched into one image.
Only small decorative chapter-opening images occur as embedded PDF image objects and are excluded.
Each table link is limited to its relevant question. Chapter 1 question 20 has no printed explanation.
The book dates from 2022; medical currency and word-for-word visual verification of all text remain open.
import_ready is false; consult validation_report.json before import.
