# Neurology Board Review: Questions and Answers (2016)

Extraction of the user-supplied Amy McGregor / Oxford University Press book. Its copyright and catalog page date this edition 2016. Contains **1,056 numbered questions across 29 chapters**, paired with the printed answers and explanations. Printed page = PDF page minus 13.

## Files

- `questions.json` and `questions.csv`: original numbering, prompt, options, answer, explanation, separate question and answer media, chapter and index tags, and printed/PDF page provenance. The JSON retains original source lines.
- `figures/` and `media_index.json`: 103 distinct answer-page crops: 14 figures, 40 tables, and 49 boxed diagrams/scales/lists. Figure 18.2 is relevant to two cards and is linked on both answer sides. No question-page figures were found.
- `index.json`: 2,075 parsed entries from the book index, including original page references, figure/table suffixes, 29 cross-reference or heading lines, 3,581 question links, and 127 entries left unlinked because no confident question-level match was found.
- `chapter_references.json`: the end-of-chapter reference sections, separated from the last answer in 17 chapters; original unmodified lines also remain in `questions.json`.
- `source_corrections_and_review.json`: a documented printed-choice typo in chapter 14 question 24. The card corrects the repeated C label to D based on the book's D answer and explanation, while preserving the original line.

## Question formats

Multiple choice, true/false, fill-in, matching, and four two-part questions are preserved. Matching answers use item-number keys; two-part answers use a/b keys. Question formats: {'matching': 8, 'multiple_choice': 995, 'free_response': 49, 'multipart': 4}. Book answers are transcribed and checked for structural completeness, not independently validated against current clinical literature. This 2016 exam book can contain clinical statements or standards that have since changed.

The supplied PDF is not duplicated in this ZIP. The original source filename is recorded on every card.
