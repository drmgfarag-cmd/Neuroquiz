Pediatric Neurosurgery Board Review — chapter-enriched import

91 review items: 86 MCQs in the quiz section and five short-answer items in Cases & Q&A.
70 MCQs now have concise explanations grounded in their preceding chapter with PDF page provenance. 5 vascular MCQs retain their full printed explanations. Five Q&A items retain their printed answers. 11 MCQs have no chapter-supported explanation identified and are explicitly flagged.
25 individually linked answer assets include chapter tables, therapeutic boxes, a CSF shunt infection algorithm, and two separate shunt-infection figure panels. Captions are included on each reference.
Printed keys are unchanged. Conflicting or weakly supported answers are tagged in review_required and detailed in chapter_evidence_audit.json.
Import this ZIP as one new book or reimport it to replace only this same book ID. Preserve any local edits by exporting progress beforehand.
