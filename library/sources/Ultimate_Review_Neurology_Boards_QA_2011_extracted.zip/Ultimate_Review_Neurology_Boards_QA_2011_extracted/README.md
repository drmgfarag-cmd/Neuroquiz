# Ultimate Review for the Neurology Boards: Q&A Companion (2011)

This extraction contains 579 numbered questions across 23 subject chapters and a 125-question mock examination. Each record includes the book's answer, available rationale, choice text, chapter tag, PDF page, and printed-page reference. Shared matching lists and clinical prompts are attached to their questions. The book has a contents list but no alphabetical index, so topic tags use its chapter titles.

`questions.json` preserves raw source lines as well as joined searchable text; `questions.csv` is a flat export. `question_media` and `answer_media` point to separate crops according to the side where the figure or table appeared. `high_yield_tables.json` captures the 70 final review tables with searchable extracted text and a faithful page crop for every part. Source PDF pages are 1-based. `media_index.json` gives image provenance and PDF crop coordinates. Printed page labels are read from each page because numbering resets across sections.

The source omits an explanation for some answers; those records say `not_provided_in_source`. No rationale was invented. The mock answer key was compared against all 125 separately parsed answers in `answer_key_audit.json`. This is a faithful extraction, not an independent clinical accuracy review; use the original book to verify high-stakes study decisions.
