Vascular Neurosurgery: In Multiple-Choice Questions — Samer S. Hoz (2017)

VASC2017_extraction.json contains all 349 questions in seven chapters, the 349 printed answer letters, available explanations, the Chapter 2 shared case, exact PDF page references, and ten linked cropped tables. The source audit matches all 349 stems and 1,744 option texts to their cited pages.

images/ contains ten complete vector-table crops as RGB PNG, each with four edges and white padding. The Bicêtre neonatal score from PDF pages 179–180 is stitched into one linked asset. Names include the book name, year, chapter, and related question; cover graphics are excluded.

SOURCE ANOMALY: Chapter 7, Q17 prints only options A–D and says “The answer is E.” The adjacent explanation describes D as the false statement. The JSON retains printed_correct_answer=E and records correct_answer=D as a source-internal correction. This question stays on publication_hold and requires medical review before release.

This 2017 book has not received a medical currency review; global import_ready is false. The ZIP has been checked for CRC errors and completeness.
