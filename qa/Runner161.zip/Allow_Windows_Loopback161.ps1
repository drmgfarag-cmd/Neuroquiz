[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateRange(1,2147483647)][int]$AppProcessId,
 [ValidateRange(1,35)][int]$WaitSeconds=30
)
# Normal policy applies. No policy or permission API is changed; only the exact
# owned native consent control can be invoked.
$ErrorActionPreference='Stop'
$clock=[Diagnostics.Stopwatch]::StartNew()
$expectedTitle='NeuroQuiz permission'
$expectedMessage='Allow NeuroQuiz to connect to your local sync server?'
$observation=[ordered]@{
 format='neuroquiz-owned-windows-loopback-permission161-v1';platform='win32';
 appProcessId=$AppProcessId;status='ERROR';startedAtUtc=[DateTime]::UtcNow.ToString('o');
 waitLimitMilliseconds=($WaitSeconds*1000);pollMilliseconds=150;
 sameTitleOwnedWindowsObserved=0;exactMessageObserved=$false;invoked=$false;
 exactTitleRequired=$expectedTitle;exactMessageRequired=$expectedMessage;
 exactButtonRequired='Allow';unrelatedWindowsInvoked=$false
}
try {
 if($env:OS -ne 'Windows_NT'){throw 'Native Windows is required.'}
 $owned=Get-Process -Id $AppProcessId -ErrorAction Stop
 if($owned.ProcessName -notin @('NeuroQuiz','NeuroQuiz-QA')){throw 'The supplied owned PID is not NeuroQuiz.'}
 $startedTicks=$owned.StartTime.ToUniversalTime().Ticks
 $observation.processName=$owned.ProcessName
 $observation.processStartedAtUtc=$owned.StartTime.ToUniversalTime().ToString('o')
 Add-Type -AssemblyName UIAutomationClient
 Add-Type -AssemblyName UIAutomationTypes
 $pidCondition=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::ProcessIdProperty,$AppProcessId)
 $titleCondition=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::NameProperty,$expectedTitle)
 $windowCondition=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::ControlTypeProperty,[System.Windows.Automation.ControlType]::Window)
 $pidTitleCondition=[System.Windows.Automation.AndCondition]::new($pidCondition,$titleCondition)
 $candidateCondition=[System.Windows.Automation.AndCondition]::new($pidTitleCondition,$windowCondition)
 $messageName=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::NameProperty,$expectedMessage)
 $textType=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::ControlTypeProperty,[System.Windows.Automation.ControlType]::Text)
 $messageCondition=[System.Windows.Automation.AndCondition]::new($messageName,$textType)
 $buttonType=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::ControlTypeProperty,[System.Windows.Automation.ControlType]::Button)
 $allowName=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::NameProperty,'Allow')
 $cancelName=[System.Windows.Automation.PropertyCondition]::new([System.Windows.Automation.AutomationElement]::NameProperty,'Cancel')
 $allowCondition=[System.Windows.Automation.AndCondition]::new($allowName,$buttonType)
 $cancelCondition=[System.Windows.Automation.AndCondition]::new($cancelName,$buttonType)
 while($clock.Elapsed.TotalSeconds -lt $WaitSeconds){
  $current=Get-Process -Id $AppProcessId -ErrorAction Stop
  if($current.ProcessName -notin @('NeuroQuiz','NeuroQuiz-QA') -or $current.StartTime.ToUniversalTime().Ticks -ne $startedTicks){throw 'Owned process identity changed; no permission was invoked.'}
  $windows=[System.Windows.Automation.AutomationElement]::RootElement.FindAll([System.Windows.Automation.TreeScope]::Children,$candidateCondition)
  if($windows.Count -gt 1){$observation.status='REFUSED';$observation.reason='Multiple owned windows have the exact permission title.';break}
  if($windows.Count -eq 1){
   $observation.sameTitleOwnedWindowsObserved++
   $window=$windows.Item(0)
   $messages=$window.FindAll([System.Windows.Automation.TreeScope]::Descendants,$messageCondition)
   $allows=$window.FindAll([System.Windows.Automation.TreeScope]::Descendants,$allowCondition)
   $cancels=$window.FindAll([System.Windows.Automation.TreeScope]::Descendants,$cancelCondition)
   if($messages.Count -eq 1 -and $allows.Count -eq 1 -and $cancels.Count -eq 1){
    $observation.exactMessageObserved=$true
    $message=$messages.Item(0);$allow=$allows.Item(0);$cancel=$cancels.Item(0)
    # Recheck every acted-on element and the native window immediately before Invoke.
    if($window.Current.ProcessId -ne $AppProcessId -or $window.Current.Name -cne $expectedTitle -or
       $message.Current.ProcessId -ne $AppProcessId -or $message.Current.Name -cne $expectedMessage -or
       $allow.Current.ProcessId -ne $AppProcessId -or $allow.Current.Name -cne 'Allow' -or
       $cancel.Current.ProcessId -ne $AppProcessId -or $cancel.Current.Name -cne 'Cancel'){
      $observation.status='REFUSED';$observation.reason='Exact PID/title/message/button identity changed.';break
    }
    if($allow.Current.IsEnabled -and -not $allow.Current.IsOffscreen -and $cancel.Current.IsEnabled){
     $current=Get-Process -Id $AppProcessId -ErrorAction Stop
     if($current.StartTime.ToUniversalTime().Ticks -ne $startedTicks){throw 'Owned PID was replaced before invocation.'}
     $invoke=$null
     if(-not $allow.TryGetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern,[ref]$invoke)){
      $observation.status='REFUSED';$observation.reason='Exact Allow control has no native Invoke pattern.';break
     }
     ([System.Windows.Automation.InvokePattern]$invoke).Invoke()
     $observation.status='ALLOWED';$observation.invoked=$true
     $observation.invokedAtUtc=[DateTime]::UtcNow.ToString('o');break
    }
   }
  }
  Start-Sleep -Milliseconds 150
 }
 if($observation.status -eq 'ERROR'){
  if($observation.sameTitleOwnedWindowsObserved -gt 0){$observation.status='REFUSED';$observation.reason='Owned permission title appeared without the complete exact loopback message and controls.'}
  else{$observation.status='NOT_SHOWN';$observation.reason='No exact owned permission window appeared during the bounded observation.'}
 }
} catch {
 $observation.status='ERROR';$observation.reason=[string]$_.Exception.Message
}
$observation.elapsedMilliseconds=[int]$clock.ElapsedMilliseconds
$observation.finishedAtUtc=[DateTime]::UtcNow.ToString('o')
[Console]::Out.WriteLine(($observation|ConvertTo-Json -Depth 6 -Compress))
if($observation.status -in @('ALLOWED','NOT_SHOWN')){exit 0}else{exit 2}
