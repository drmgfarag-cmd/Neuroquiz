[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Bundle,[Parameter(Mandatory=$true)][string]$HostOutput,[Parameter(Mandatory=$true)][string]$WsbPath)
$ErrorActionPreference='Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Run this on your Windows PC.' }
$Bundle=(Resolve-Path -LiteralPath $Bundle).Path
if (Test-Path -LiteralPath $HostOutput) { throw 'Choose a new empty output folder.' }
if (Test-Path -LiteralPath $WsbPath) { throw 'An existing Sandbox configuration will not be overwritten.' }
if (-not (Get-Command WindowsSandbox.exe -ErrorAction SilentlyContinue)) { throw 'Windows Sandbox is unavailable. Use a new disposable Windows user, or install the Microsoft optional feature using the dependency guide.' }
New-Item -ItemType Directory -Path $HostOutput|Out-Null
$b=[Security.SecurityElement]::Escape($Bundle);$o=[Security.SecurityElement]::Escape((Resolve-Path -LiteralPath $HostOutput).Path)
$xml=@"
<Configuration>
 <VGpu>Default</VGpu><Networking>Enable</Networking><ClipboardRedirection>Disable</ClipboardRedirection><PrinterRedirection>Disable</PrinterRedirection>
 <MappedFolders>
  <MappedFolder><HostFolder>$b</HostFolder><SandboxFolder>C:\NQ161</SandboxFolder><ReadOnly>true</ReadOnly></MappedFolder>
  <MappedFolder><HostFolder>$o</HostFolder><SandboxFolder>C:\NQ161-Results</SandboxFolder><ReadOnly>false</ReadOnly></MappedFolder>
 </MappedFolders>
 <LogonCommand><Command>powershell.exe -NoProfile -File C:\NQ161\Sandbox_Start161.ps1</Command></LogonCommand>
</Configuration>
"@
$xml|Set-Content -LiteralPath $WsbPath -Encoding UTF8
Write-Host "Open $WsbPath to run in a fresh real Windows guest. Only the selected results folder is writable. Keep Sandbox open until the guide and all evidence collection finish."
