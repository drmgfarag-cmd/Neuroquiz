[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Target,[Parameter(Mandatory=$true)][string]$Output,[Parameter(Mandatory=$true)][switch]$DedicatedDisposableWindowsUser)
$ErrorActionPreference='Stop'
if($env:OS -ne 'Windows_NT' -or  -not $DedicatedDisposableWindowsUser){throw 'Use a real dedicated Windows test user/Sandbox.'}
$Target=(Resolve-Path -LiteralPath $Target).Path;$targetHash=(Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash.ToLowerInvariant();$t=Get-Content -LiteralPath $Target -Raw|ConvertFrom-Json
$ownerPath=Join-Path $Output 'run-owner.json';if( -not (Test-Path -LiteralPath $ownerPath)){throw 'Run the exact bound installed automation first.'};$owner=Get-Content -LiteralPath $ownerPath -Raw|ConvertFrom-Json
if($owner.targetSha256 -ne $targetHash -or $owner.windowsUser -ne $env:USERNAME){throw 'Other target/user output refused.'}
$scope=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Original_Full_Scope160.json') -Raw|ConvertFrom-Json
if($scope.criteria.Count -ne 186 -or $scope.requirements.Count -ne 67){throw 'Original finite scope differs.'}
$dir=Join-Path $Output 'attended';if( -not (Test-Path -LiteralPath $dir)){New-Item -ItemType Directory -Path $dir|Out-Null}
Add-Type -AssemblyName System.Windows.Forms;Add-Type -AssemblyName System.Drawing;Add-Type -AssemblyName UIAutomationClient;Add-Type -AssemblyName UIAutomationTypes
$items=@();foreach($c in $scope.criteria){$req=$scope.requirements|Where-Object{$_.id -eq $c.requirementId};$items+=@{id=$c.criterionId;expected=$c.originalRequiredAssertion;steps=$req.steps;kind='original-atomic'}}
foreach($c in $scope.enhancements){$items+=@{id=$c.id;expected=($c.originalAcceptanceCriteria-join"`n");steps='Perform every original enhancement assertion using the exact original source and the installed Windows UI.';kind='enhancement'}}
foreach($c in $scope.desktopNativeAdditionalGates){if($c.id -ne 'WIN_UPGRADE_PRESERVE'){$items+=@{id=$c.id;expected=$c.requiredObservedWork;steps=$c.requiredObservedWork;kind='native'}}}
$extensions=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Scope_Extensions161.json') -Raw|ConvertFrom-Json
foreach($c in $extensions.extensions){$items+=@{id=$c.id;expected=($c.requiredAssertions-join"`n");steps='Perform and retain every new161 assertion; real source/client/OS observations are required.';kind='extension161'}}
foreach($c in $items){
 $record=Join-Path $dir ($c.id+'.json');if(Test-Path -LiteralPath $record){continue}
 Write-Host "`n$($c.id): $($c.expected)`nProcedure: $($c.steps)"
 Write-Host 'Perform the actual steps. PASS requires every printed condition and retained physical/OS evidence. Prepared text or a route heading is insufficient.'
 $status=(Read-Host 'P=observed PASS, F=observed FAIL, B=BLOCKED, Q=save and stop').ToUpperInvariant();if($status -eq 'Q'){break};if($status -notin @('P','F','B')){throw 'Invalid outcome; no record written.'}
 $observed=Read-Host 'Describe the actual observed result and relevant source/profile/session identity';if($observed.Length -lt 20){throw 'A concrete observed result is required.'}
 $additional=Read-Host 'Existing physical output/log/audio evidence file paths, separated by semicolon (required when the assertion needs them)'
 $evidence=@();foreach($p in($additional-split';')){if($p.Trim()){$f=Get-Item -LiteralPath $p.Trim();if($f.PSIsContainer){throw 'Evidence must be a file.'};$dest=Join-Path $dir ($c.id+'-'+[Guid]::NewGuid().ToString('N')+'-'+$f.Name);Copy-Item -LiteralPath $f.FullName -Destination $dest;$evidence+=@{file=(Split-Path -Leaf $dest);bytes=(Get-Item -LiteralPath $dest).Length;sha256=(Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()}}}
 $screen=Join-Path $dir ($c.id+'.png');$bounds=[System.Windows.Forms.SystemInformation]::VirtualScreen;$bmp=New-Object System.Drawing.Bitmap $bounds.Width,$bounds.Height;$g=[System.Drawing.Graphics]::FromImage($bmp);$g.CopyFromScreen($bounds.X,$bounds.Y,0,0,$bmp.Size);$bmp.Save($screen,[System.Drawing.Imaging.ImageFormat]::Png);$g.Dispose();$bmp.Dispose();$evidence+=@{file=(Split-Path -Leaf $screen);bytes=(Get-Item -LiteralPath $screen).Length;sha256=(Get-FileHash -LiteralPath $screen -Algorithm SHA256).Hash.ToLowerInvariant()}
 $tree=Join-Path $dir ($c.id+'.uia.json');$root=[System.Windows.Automation.AutomationElement]::RootElement;$nodes=$root.FindAll([System.Windows.Automation.TreeScope]::Children,[System.Windows.Automation.Condition]::TrueCondition);$uia=@();foreach($node in $nodes){$s=$node.Current;$uia+=@{name=if($s.IsPassword){'<protected>'}else{$s.Name};automationId=$s.AutomationId;processId=$s.ProcessId;controlType=$s.ControlType.ProgrammaticName}}
 $uia|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $tree -Encoding UTF8;$evidence+=@{file=(Split-Path -Leaf $tree);bytes=(Get-Item -LiteralPath $tree).Length;sha256=(Get-FileHash -LiteralPath $tree -Algorithm SHA256).Hash.ToLowerInvariant()}
 $r=@{format='neuroquiz-attended-windows-evidence161-v1';id=$c.id;kind=$c.kind;expected=$c.expected;observed=$observed;status=(@{P='PASS';F='FAIL';B='BLOCKED'})[$status];runId=$owner.runId;targetSha256=$targetHash;platform='win32';windowsBuild=[Environment]::OSVersion.VersionString;windowsUser=$env:USERNAME;recordedAtUtc=[DateTime]::UtcNow.ToString('o');actualWindowsCapture=$true;evidence=$evidence;spokenOutputAutomaticallyProved=$false;fullWindowsAcceptance=$false}
 $r|ConvertTo-Json -Depth 15|Set-Content -LiteralPath $record -Encoding UTF8
}
Write-Host 'Records are retained without overwriting. Run Validate_Windows161.cjs to identify remaining gates; no blanket acceptance is awarded.'
