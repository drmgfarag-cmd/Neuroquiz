$ErrorActionPreference='Stop'
$bundle='C:\NQ161';$work='C:\NQ161-Work';New-Item -ItemType Directory -Path $work|Out-Null
Copy-Item -Path "$bundle\*" -Destination $work -Recurse
Set-Location $work
foreach($script in Get-ChildItem -Path $work -Filter *.ps1 -Recurse){
 $tokens=$null;$parseErrors=$null
 [void][Management.Automation.Language.Parser]::ParseFile($script.FullName,[ref]$tokens,[ref]$parseErrors)
 if($parseErrors.Count){throw ($script.FullName+': '+($parseErrors.Message -join '; '))}
}
Write-Host 'This is a fresh Windows test environment. The host app and learner folders are not mapped.'
$target=Join-Path $work 'Windows_Target161.json';if(-not(Test-Path -LiteralPath $target)){throw 'The bundle has not been bound to the final installer. Ask for the completed Windows161 acceptance bundle.'}
$t=Get-Content -LiteralPath $target -Raw|ConvertFrom-Json
$bootstrap=Join-Path $work 'tools\setup\Setup_NeuroQuiz_Source.cmd'
if(-not(Test-Path -LiteralPath $bootstrap)){throw 'The verified acceptance dependency setup launcher is missing.'}
$setupReport='C:\NQ161-Results\Setup_Node161.json';$setupConsole='C:\NQ161-Results\Setup_Node161_console.txt'
$lock=@($t.harnessFiles|Where-Object {$_.path -eq 'package-lock.json'})
if($lock.Count -ne 1){throw 'Bound dependency lock missing.'}
& $bootstrap --node-only --report-path $setupReport --install-locked-packages --package-dir $work --expected-lock-sha256 $lock[0].sha256 2>&1 | Tee-Object -FilePath $setupConsole
$setupExit=$LASTEXITCODE
if($setupExit -ne 0 -or -not(Test-Path -LiteralPath $setupReport)){throw 'Dependency setup is BLOCKED. Preserve the console log; the bootstrap may stop before producing JSON.'}
$n=Get-Content -LiteralPath $setupReport -Raw|ConvertFrom-Json
if(-not $n.succeeded){throw 'Acceptance dependency setup failed; review the saved setup report.'}
& $n.node.exe --test (Join-Path $work 'tests\runner-contract.test.cjs') (Join-Path $work 'tests\sync-peer-contract.test.cjs')
if($LASTEXITCODE -ne 0){throw 'Acceptance host contracts failed before app installation.'}
& (Join-Path $work 'Start_Windows_Acceptance161.ps1') -Target $target -Installer (Join-Path $work $t.installer.filename) -Output 'C:\NQ161-Results\Run161' -DedicatedDisposableWindowsUser -NodeExe $n.node.exe
Write-Host 'Automation ended or recorded its failures. Continue the attended checks while this Sandbox remains open.'
& (Join-Path $work 'Record_Windows_Manual161.ps1') -Target $target -Output 'C:\NQ161-Results\Run161' -DedicatedDisposableWindowsUser
& $n.node.exe (Join-Path $work 'Validate_Windows161.cjs') --target $target --output 'C:\NQ161-Results\Run161' --report 'C:\NQ161-Results\Windows_Qualification161.json'
