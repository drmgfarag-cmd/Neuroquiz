[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Target,[Parameter(Mandatory=$true)][string]$Installer,[Parameter(Mandatory=$true)][string]$Output,[Parameter(Mandatory=$true)][switch]$DedicatedDisposableWindowsUser,[string]$NodeExe='node',[switch]$ResumeOwnedRun)
$ErrorActionPreference='Stop'
if ($env:OS -ne 'Windows_NT') { throw 'A real Windows host is required. Linux, Wine and browser simulations do not count.' }
if (-not $DedicatedDisposableWindowsUser) { throw 'Use a fresh dedicated test user or the supplied Windows Sandbox. Existing learner data is never a test fixture.' }
if (-not (Get-Command $NodeExe -ErrorAction SilentlyContinue)) { throw 'Acceptance tools need Node. Run the verified Setup_NeuroQuiz_Source.cmd first. The installed app itself does not require Node.' }
& $NodeExe --version
if ($LASTEXITCODE -ne 0) { throw 'The acceptance Node runtime could not start. Nothing was installed.' }
$Target=(Resolve-Path -LiteralPath $Target).Path
$Installer=(Resolve-Path -LiteralPath $Installer).Path
$t=Get-Content -LiteralPath $Target -Raw | ConvertFrom-Json
$targetHash=(Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash.ToLowerInvariant()
if ($t.format -ne 'neuroquiz-windows-bound-target161-v1' -or -not $t.freshInstallDefault) { throw 'Reviewed fresh-install target required.' }
if ((Get-Item -LiteralPath $Installer).Length -ne $t.installer.bytes -or (Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLowerInvariant() -ne $t.installer.sha256) { throw 'Installer identity differs.' }
$InstallRoot=Join-Path $env:LOCALAPPDATA 'Programs\NeuroQuiz'
$UserData=Join-Path $env:APPDATA 'neuroquiz-desktop'
if (Get-Process -Name NeuroQuiz -ErrorAction SilentlyContinue) { throw 'An existing NeuroQuiz test process is running. Close that owned test app before continuing.' }
$Output=[IO.Path]::GetFullPath($Output)
$freshReceipt=$Output+'.fresh-install.json'
if ($ResumeOwnedRun) {
 $Owner=Join-Path $Output 'run-owner.json'
 if (-not (Test-Path -LiteralPath $Owner)) { throw 'Resume requires an existing same-target run marker.' }
 $r=Get-Content -LiteralPath $Owner -Raw | ConvertFrom-Json
 if ($r.targetSha256 -ne $targetHash -or $r.windowsUser -ne $env:USERNAME) { throw 'Resume belongs to another target/user.' }
 $freshReceipt=Join-Path $Output 'fresh-install.json'
} else {
 if ((Test-Path -LiteralPath $InstallRoot) -or (Test-Path -LiteralPath $UserData) -or (Test-Path -LiteralPath $Output) -or (Test-Path -LiteralPath $freshReceipt)) { throw 'Fresh install requires empty installation, data and output. Use Windows Sandbox; do not remove existing learner data.' }
 $parent=Split-Path -Parent $Output
 if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
 $started=[DateTime]::UtcNow.ToString('o')
 $p=Start-Process -FilePath $Installer -ArgumentList '/S' -PassThru -Wait
 $receipt=@{runId=[guid]::NewGuid().ToString();intendedOutputPath=$Output;format='neuroquiz-windows-fresh-install161-v1';targetSha256=$targetHash;installerSha256=$t.installer.sha256;installerExitCode=$p.ExitCode;preInstall=@{installationAbsent=$true;userDataAbsent=$true};platform='win32';windowsUser=$env:USERNAME;windowsUserSid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;windowsBuild=[Environment]::OSVersion.VersionString;startedAtUtc=$started;finishedAtUtc=[DateTime]::UtcNow.ToString('o')}
 $receipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $freshReceipt -Encoding UTF8
 if ($p.ExitCode -ne 0) { throw "Installer failed: $($p.ExitCode). Its failure receipt is retained." }
}
$Exe=Join-Path $InstallRoot 'NeuroQuiz.exe'
if (-not (Test-Path -LiteralPath $Exe)) { throw 'Installed executable missing.' }
& $NodeExe (Join-Path $PSScriptRoot 'Run_Windows161.cjs') $Target $Exe $Output $freshReceipt
$code=$LASTEXITCODE
Write-Host 'Automation outcomes are preserved. Continue the attended atomic/native checks with Record_Windows_Manual161.ps1.'
exit $code
