'use strict';
/** Qualify retained Windows evidence; running this verifier is not a Windows test. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const HERE = __dirname;
const REQUIRED_HARNESS = [
  "Scope_Extensions161.json",
  "Windows_Scheduler161.cjs",
  "Windows_Sync161.cjs", "Allow_Windows_Loopback161.ps1",
  "Start_Windows_Acceptance161.ps1",
  "Windows_Cases161.cjs",
  "Case_Catalog161.json",
  "Run_Windows161.cjs",
  "Record_Windows_Manual161.ps1",
  "Validate_Windows161.cjs",
  "Original_Full_Scope160.json",
  "Original_Routes160.json",
  "oracles/enhancement157.js",
  "NQ_Synthetic_Native115.zip",
  "package-lock.json",
  "package.json",
  "tests/runner-contract.test.cjs", "tests/sync-peer-contract.test.cjs",
  "Sandbox_Start161.ps1",
  "Prepare_Windows_Sandbox161.ps1",
  "tools/setup/Setup_NeuroQuiz_Source.cmd",
  "tools/setup/Setup_NeuroQuiz_Source.ps1",
  "tools/setup/dependency-doctor.cjs",
  "tools/setup/Dependency_Downloads161.json"
];
const PHYSICAL_GATES = new Set([
  'WIN_EXPORT_READBACK', 'WIN_RECOVERY_ATOMIC', 'WIN_AT_KEYBOARD',
  'WIN_FULL_CORPUS', 'WIN_CONFIGURED_SERVICES', 'WIN_ORIGINAL_PDF',
  'VISUAL_ANKI_CLIENT161', 'PERSONAL_CALIBRATION161',
  'FULL_CORPUS_MEASUREMENTS161', 'DEPENDENCIES161'
]);
const HEX = /^[a-f0-9]{64}$/;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[1-5][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i;
const read = file => JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
function sha(file) {
  const hash = crypto.createHash('sha256'), buffer = Buffer.allocUnsafe(8 * 1024 * 1024);
  const fd = fs.openSync(file, 'r');
  try {
    let size;
    while ((size = fs.readSync(fd, buffer, 0, buffer.length, null)) > 0) hash.update(buffer.subarray(0, size));
    return hash.digest('hex');
  } finally { fs.closeSync(fd); }
}
function regular(file) {
  const st = fs.lstatSync(file);
  assert(st.isFile() && !st.isSymbolicLink(), 'Regular non-symlink evidence required: ' + file);
  return st;
}
function samePin(file, row) {
  assert(Number.isSafeInteger(row.bytes) && row.bytes >= 0 && HEX.test(row.sha256), 'Invalid file pin');
  assert.equal(regular(file).size, row.bytes, 'File size differs: ' + file);
  assert.equal(sha(file), row.sha256, 'File SHA256 differs: ' + file);
}
function relativeName(name) {
  assert(typeof name === 'string' && name.length && !name.includes('\0'), 'Evidence name absent');
  assert.equal(path.posix.basename(name), name, 'Nested evidence path refused');
  assert.equal(path.win32.basename(name), name, 'Windows path escape refused');
  assert(!['.', '..'].includes(name), 'Dot evidence path refused');
  return name;
}
function windowsPath(value) {
  assert(typeof value === 'string' && path.win32.isAbsolute(value), 'Absolute original Windows path required');
  return path.win32.normalize(value).replace(/[\\/]+$/, '').toLowerCase();
}
function addExpected(expected, id, assertion) {
  assert(/^[a-z0-9_.-]+$/i.test(id), 'Unsafe finite criterion identity');
  assert(typeof assertion === 'string' && assertion.length, 'Original assertion absent: ' + id);
  assert(!expected.has(id), 'Duplicate finite criterion: ' + id);
  expected.set(id, assertion);
}
function evidenceFile(output, relative) {
  const file = path.join(output, relative);
  regular(file);
  return file;
}
function qualify({targetPath, output, report}) {
  assert(targetPath && output && report, 'targetPath, output and a fresh report path are required');
  targetPath = path.resolve(targetPath);
  output = path.resolve(output);
  report = path.resolve(report);
  assert(!fs.existsSync(report), 'Never overwrite a prior qualification');
  regular(targetPath);
  const target = read(targetPath), targetSha256 = sha(targetPath);
  assert.equal(target.format, 'neuroquiz-windows-bound-target161-v1');
  assert.equal(target.release, 161);
  assert.equal(target.freshInstallDefault, true);
  assert.equal(target.upgradesRequested, false);
  assert(target.installer && HEX.test(target.installer.sha256), 'Installer identity absent');
  assert(Array.isArray(target.installedPayloads) && target.installedPayloads.length >= 278, 'Installed payload set absent');
  const payloadNames = new Set();
  for (const row of target.installedPayloads) {
    assert(typeof row.path === 'string' && !/[<>:"|?*\0]/.test(row.path) && !path.win32.isAbsolute(row.path) && !path.posix.isAbsolute(row.path));
    assert(!row.path.split(/[\\/]/).some(part => !part || ['.', '..'].includes(part)));
    assert(!payloadNames.has(row.path.toLowerCase()), 'Duplicate installed payload');
    payloadNames.add(row.path.toLowerCase());
    assert(Number.isSafeInteger(row.bytes) && row.bytes >= 0 && HEX.test(row.sha256));
  }
  const exe = target.installedPayloads.find(row => row.path.toLowerCase() === 'neuroquiz.exe');
  assert(exe, 'Exact installed NeuroQuiz.exe payload required');
  assert(Array.isArray(target.harnessFiles), 'Bound harness set absent');
  assert.deepEqual(target.harnessFiles.map(row => row.path).sort(), REQUIRED_HARNESS.slice().sort(), 'Exact unique canonical harness set required');
  for (const row of target.harnessFiles) samePin(path.join(HERE, ...row.path.split('/')), row);

  const scope = read(path.join(HERE, 'Original_Full_Scope160.json'));
  const extensions = read(path.join(HERE, 'Scope_Extensions161.json'));
  const catalog = read(path.join(HERE, 'Case_Catalog161.json'));
  assert.equal(catalog.sourceSha256, sha(path.join(HERE, 'Windows_Cases161.cjs')), 'Case catalog is stale');
  assert.equal(scope.criteria.length, 186);
  assert.equal(scope.requirements.length, 67);
  assert.equal(scope.enhancements.length, 8);
  assert.equal(extensions.extensions.length, 6);
  assert.equal(catalog.cases.length, 78, 'Exact current 78-case selection required');
  const ids = catalog.cases.map(row => relativeName(row.id));
  assert.equal(new Set(ids).size, 78);
  assert.equal(ids[0], 'fresh_home_first_run', 'First run must precede imports and personal test work');

  const auto = read(evidenceFile(output, 'Windows_Automation161.json'));
  const owner = read(evidenceFile(output, 'run-owner.json'));
  const freshFile = evidenceFile(output, 'fresh-install.json');
  const fresh = read(freshFile);
  assert.equal(auto.format, 'neuroquiz-real-windows-automation161-v1');
  assert.equal(owner.format, 'neuroquiz-windows-run-owner161-v1');
  assert.equal(auto.targetSha256, targetSha256);
  assert.equal(owner.targetSha256, targetSha256);
  assert.equal(auto.nativeWindowsExecuted, true);
  assert.equal(auto.allSelectedCasesHaveTerminalRecord, true);
  assert(UUID.test(auto.runId), 'Actual bound run nonce required');
  assert.equal(owner.runId, auto.runId);
  assert.equal(fresh.runId, auto.runId, 'Fresh-install receipt belongs to another run');
  assert.equal(fresh.format, 'neuroquiz-windows-fresh-install161-v1');
  assert.equal(fresh.targetSha256, targetSha256);
  assert.equal(fresh.installerSha256, target.installer.sha256);
  assert.equal(fresh.installerExitCode, 0);
  assert.deepEqual(fresh.preInstall, {installationAbsent:true, userDataAbsent:true});
  assert.equal(fresh.platform, 'win32');
  assert(typeof fresh.windowsUserSid === 'string' && fresh.windowsUserSid.length);
  assert(typeof fresh.windowsBuild === 'string' && fresh.windowsBuild.length);
  assert(typeof auto.windowsUser === 'string' && auto.windowsUser.length);
  assert.equal(fresh.windowsUser, auto.windowsUser);
  assert.equal(owner.windowsUser, auto.windowsUser);
  assert.equal(sha(freshFile), auto.freshInstallReceiptSha256);
  assert.equal(sha(freshFile), owner.freshInstallReceiptSha256);
  const intendedOutputPath = windowsPath(fresh.intendedOutputPath);
  assert.equal(windowsPath(auto.intendedOutputPath), intendedOutputPath, 'Automation output binding differs');
  assert.equal(windowsPath(owner.intendedOutputPath), intendedOutputPath, 'Owner output binding differs');
  // Rehosting genuine raw records for verification changes their local path, not
  // the original Windows receipt/owner/run. On Windows, also bind the live path.
  if (process.platform === 'win32') assert.equal(windowsPath(output), intendedOutputPath, 'Wrong live Windows output directory');
  assert.deepEqual(auto.selectedCases, ids);
  assert.deepEqual(owner.selectedCases, ids);
  assert.deepEqual(auto.records.map(row => row.caseId), ids);
  const counts = {PASS:0, FAIL:0, BLOCKED:0, CRASH:0};
  for (const row of auto.records) {
    assert.equal(row.runId, auto.runId);
    assert.equal(row.targetSha256, targetSha256);
    assert.equal(row.platform, 'win32');
    assert(Object.hasOwn(counts, row.status), 'Unknown actual case status');
    counts[row.status]++;
    const source = evidenceFile(output, path.join(row.caseId, row.status === 'CRASH' ? 'crash.json' : 'result.json'));
    assert.deepEqual(read(source), row, 'Actual per-case record differs from rollup');
    if (row.status === 'PASS') {
      assert.equal(row.nativeWindowsExecuted, true);
      assert(Number.isSafeInteger(row.appPid) && row.appPid > 0);
      assert.equal(row.executableSha256, exe.sha256, 'Running executable byte identity differs');
      const runtime = row.actualElectronRuntime;
      assert(runtime && runtime.platform === 'win32', 'Actual Electron Windows runtime proof absent');
      assert.equal(runtime.pid, row.appPid, 'Electron runtime PID differs');
      assert(typeof runtime.arch === 'string' && ['x64', 'arm64'].includes(runtime.arch));
      assert.equal(path.win32.basename(runtime.execPath).toLowerCase(), 'neuroquiz.exe');
      windowsPath(runtime.execPath);
      windowsPath(runtime.appPath);
      assert(typeof runtime.electronVersion === 'string' && /^\d+\.\d+\.\d+/.test(runtime.electronVersion));
      assert(typeof runtime.nodeVersion === 'string' && /^\d+\.\d+\.\d+/.test(runtime.nodeVersion));
      assert(typeof runtime.appVersion === 'string' && runtime.appVersion.length);
    }
  }
  assert.deepEqual(auto.counts, counts, 'Case-count summary differs from exact records');
  const expected = new Map();
  for (const row of scope.criteria) addExpected(expected, row.criterionId, row.originalRequiredAssertion);
  for (const row of scope.enhancements) addExpected(expected, row.id, row.originalAcceptanceCriteria.join('\n'));
  const nativeGates = scope.desktopNativeAdditionalGates.filter(row => row.id !== 'WIN_UPGRADE_PRESERVE');
  assert.equal(nativeGates.length, 13);
  for (const row of nativeGates) addExpected(expected, row.id, row.requiredObservedWork);
  for (const row of extensions.extensions) addExpected(expected, row.id, row.requiredAssertions.join('\n'));
  assert.equal(expected.size, 213, 'Exact original, enhancement, native and new161 scope required');

  const records = [], missing = [], invalidEvidence = [];
  for (const [id, assertion] of expected) {
    const file = path.join(output, 'attended', id + '.json');
    if (!fs.existsSync(file)) { missing.push(id); continue; }
    try {
      regular(file);
      const row = read(file);
      assert.equal(row.format, 'neuroquiz-attended-windows-evidence161-v1');
      assert.equal(row.id, id);
      assert.equal(row.expected, assertion, 'Verbatim original assertion differs');
      assert.equal(row.runId, auto.runId);
      assert.equal(row.targetSha256, targetSha256);
      assert.equal(row.platform, 'win32');
      assert.equal(row.actualWindowsCapture, true);
      assert.equal(row.windowsUser, auto.windowsUser, 'Attended record belongs to another Windows user');
      assert(typeof row.windowsBuild === 'string' && row.windowsBuild.length, 'Actual Windows build absent');
      assert(['PASS', 'FAIL', 'BLOCKED'].includes(row.status));
      assert(typeof row.observed === 'string' && row.observed.length >= 20, 'Concrete observed result absent');
      assert(Array.isArray(row.evidence) && row.evidence.length >= 2, 'Actual captured evidence absent');
      const names = new Set();
      for (const item of row.evidence) {
        relativeName(item.file);
        assert(!names.has(item.file.toLowerCase()), 'Duplicate evidence file');
        names.add(item.file.toLowerCase());
        samePin(path.join(path.dirname(file), item.file), item);
      }
      if (row.status === 'PASS' && PHYSICAL_GATES.has(id)) assert(row.evidence.length >= 3, 'Physical/AT/source output evidence missing');
      records.push({id, status:row.status, recordSha256:sha(file)});
    } catch (error) {
      invalidEvidence.push({id, error:String(error.message || error)});
    }
  }
  const passed = !missing.length && !invalidEvidence.length &&
    records.every(row => row.status === 'PASS') && auto.records.every(row => row.status === 'PASS');
  const value = {
    format:'neuroquiz-windows-full-qualification161-v1', targetSha256,
    runId:auto.runId, actualWindowsAutomationExecuted:true,
    qualificationHostPlatform:process.platform,
    qualificationExecutionIsNativeWindowsAcceptance:false,
    originalWindowsOutputPath:fresh.intendedOutputPath,
    receiptOutputAndRunBindingsVerified:true,
    localPathRehostedForEvidenceQualification:process.platform !== 'win32',
    automationCounts:counts, originalAtomicCount:186, enhancementCount:8,
    new161ScopeExtensions:6, nativeGatesRequiredForFreshInstall:13,
    requiredAttendedRecords:213, upgradeCompatibilityRequired:false,
    upgradeExcludedByExplicitFreshReleasePolicy:true,
    records, missing, invalidEvidence, fullWindowsAcceptance:passed,
    scope:'Actual fresh installation only; older-installation upgrades are outside the user-requested default scope.',
    manualEvidenceIsAttendedHumanObservation:true,
    spokenOutputDerivedFromDomMetadata:false,
    sourceCaseOrRawOutcomeRelabelingPerformed:false
  };
  fs.writeFileSync(report, JSON.stringify(value, null, 2) + '\n', {flag:'wx'});
  return value;
}
module.exports = {qualify};
if (require.main === module) {
  try {
    const args = process.argv.slice(2), options = {};
    assert.equal(args.length, 6, 'Usage: node Validate_Windows161.cjs --target TARGET_JSON --output RESULT_DIRECTORY --report FRESH_REPORT');
    for (let n = 0; n < args.length; n += 2) {
      assert(['--target', '--output', '--report'].includes(args[n]), 'Unknown qualifier argument');
      assert(!Object.hasOwn(options, args[n]), 'Duplicate qualifier argument');
      options[args[n]] = args[n + 1];
    }
    const result = qualify({targetPath:options['--target'], output:options['--output'], report:options['--report']});
    process.stdout.write(JSON.stringify({fullWindowsAcceptance:result.fullWindowsAcceptance, missing:result.missing.length, invalid:result.invalidEvidence.length}) + '\n');
    process.exitCode = result.fullWindowsAcceptance ? 0 : 2;
  } catch (error) {
    process.stderr.write(JSON.stringify({valid:false, fullWindowsAcceptance:false, error:String(error.message || error)}) + '\n');
    process.exitCode = 2;
  }
}
