# Windows161 acceptance

This package prepares real Windows testing. It was prepared and its runner contracts tested on Linux. **Actual Windows executions: 0. Full Windows acceptance: incomplete.** Linux tests, a built installer and a successful CI job cannot stand in for installed Windows observations.

The normal NeuroQuiz installer contains its runtime. Users do not need Node, Python, Android tools or an SDK to open the installed app. Node and Playwright below are acceptance tools only. The final qualifier is Node; Python is needed only by the release maintainer to bind/build the package before delivery.

## Scope and evidence

`Case_Catalog161.json` lists 78 prepared functional scenarios: first empty launch, all 32 original routes, format 1–8 right/wrong controls, linked EMI boundaries, exam/tutor/read modes, exact saved-session external process death and resume, full-card Undo preimages, card creation/suspension/conversion, typed search, Q&A/cases/atlas, profiles/Guest, recovery preview, appearance persistence, Help, insufficient-history calibration defaults, and configured authenticated localhost sync with a genuine nonempty push/pull through the installed UI. The local synthetic counterpart does not close remote Android/HTTPS sync or optional AI acceptance. These are candidate scenarios. They do not automatically close all 67 original requirements or all 186 original assertions.

The attended collector separately retains 213 records: all 186 original atomic assertions, 8 enhancements, 13 applicable fresh-install native gates and 6 new161 extensions. Only the old optional upgrade-preservation native gate is outside the user's explicit fresh-release scope; no original assertion was removed. `Original_Scope_Retention161.json` in the continuation compares all original assertions to the final 160 scope. Older embedded source references in the historical scope plan are provenance, not current installer pins.

The six extensions cover the first-run guide, missing-dependency setup, organized menu/folders, **visual APKG import in a real Anki GUI**, bounded personal calibration, and **cold/warm import/search/media measurements using the complete original `Books109` and `Media109` packages**. Read `Scope_Extensions161.json` for exact assertions and original archive hashes. Do not replace the corpus with a tiny fixture, invent timing limits, infer spoken Narrator output from the DOM, or describe the four-weight initial-stability calibration as a full 21-weight optimizer. Real sufficient review history and its chronological train/held-out partitions, activation/rollback/defaults are still required for the full calibration observation.

For attended PASS, record the concrete operation and result, retain screenshots/UIA and the actual applicable output files, external-client evidence, logs or recordings. UIA alone does not prove speech, a physical chooser, sleep/resume or an external application. The qualifier checks evidence binding and completeness; it does not independently reinterpret a human's physical observations.

## Bind the actual release before delivery

The release maintainer runs these in the runner folder, after all files are frozen:

```sh
node Generate_Catalog161.cjs
python Prepare_Target161.py --installer /exact/NeuroQuiz-161-Windows-x64-Setup-Unsigned.exe --installed-payload /exact/Installed_Payload161.json --out Windows_Target161.json
python Build_Private_CI_Bundle161.py --target Windows_Target161.json --out NeuroQuiz_Windows_Acceptance161_Bundle.zip
```

The payload list must come from the exact 161 artifact. It lists every inventoried runtime/application payload, including `NeuroQuiz.exe`, with byte counts and SHA256. Never bind a160 installer as161. The target pins the installer, all installed payloads and the exact acceptance harness. A changed harness requires a new target and bundle. The allowlisted runner ZIP contains synthetic fixtures/test oracles and no application source tree, books, PDFs, signing keys, credentials, prior learner data or `node_modules`. The installer is a separate private asset.

## Fresh interactive Windows run

Use a real supported Windows machine with a new disposable Windows user, or a Windows Sandbox guest. Each release starts with absent NeuroQuiz installation/data. The scripts refuse existing learner folders and never delete them. Use the same owned output only to resume an interrupted run of the exact target; a new release gets a fresh environment and new output.

1. Extract the completed runner bundle to a normal local folder. Put its exact bound installer beside `Windows_Target161.json`. Keep the folder intact.
2. Open an ordinary terminal in that folder. Run the verified acceptance dependency helper. It checks the exact lock hash, can install a pinned per-user portable Node, and installs only locked runner packages. It skips browser/Electron downloads; tests use the actual installed app executable. The reviewed lock SHA is `8b27931eeb4133c75d4652862fceebef4961591cd980cddf446205291324399e`.

```bat
tools\setup\Setup_NeuroQuiz_Source.cmd --node-only --report-path C:\NQ161-Results\Setup_Node161.json --install-locked-packages --package-dir C:\NQ161-Runner --expected-lock-sha256 8b27931eeb4133c75d4652862fceebef4961591cd980cddf446205291324399e
```

Use your actual extracted folder for `--package-dir`. The results parent folder must exist and the report filename must be new. Retain console output. A bootstrap failure can return nonzero **before any JSON exists**; that is setup BLOCKED. Do not proceed unless exit0 and the JSON `succeeded` field are true. The verified runtime path is `report.node.exe`, not a top-level field.

3. In a PowerShell session that already permits the supplied reviewed scripts, run the guarded installer/automation launcher with that Node path:

```powershell
.\Start_Windows_Acceptance161.ps1 -Target .\Windows_Target161.json -Installer .\NeuroQuiz-161-Windows-x64-Setup-Unsigned.exe -Output C:\NQ161-Results\Run161 -DedicatedDisposableWindowsUser -NodeExe '<report.node.exe>'
.\Record_Windows_Manual161.ps1 -Target .\Windows_Target161.json -Output C:\NQ161-Results\Run161 -DedicatedDisposableWindowsUser
& '<report.node.exe>' .\Validate_Windows161.cjs --target .\Windows_Target161.json --output C:\NQ161-Results\Run161 --report C:\NQ161-Results\Windows_Qualification161.json
```

Replace the angle-bracket placeholder with the actual JSON runtime path. This package does not change execution policy or security settings. If normal script policy blocks execution, use an approved Windows test host with the scripts permitted by its owner; do not add a bypass. The PowerShell/CMD launchers have been source-reviewed but have not executed on Windows in this preparation environment.

The launcher checks Node before app installation, verifies the exact installer, records actual pre-install absence, exit code, Windows user/SID/build, output path and unique run nonce. The runner validates that receipt before creating output and refuses already-created app data on a new run. It pins every inventoried runtime/application payload, then independently launches the installed Electron app for each case. Each PASS carries the real Electron process/platform/version/executable provenance.

The loopback sync case also watches for the real native local-network consent dialog. A bounded UIAutomation helper may invoke only the exact local-sync message and Allow button belonging to that launched NeuroQuiz PID. It records ALLOWED, NOT_SHOWN or refusal/error; actual UI sync must still succeed. It does not replace permission APIs, approve notifications or contact a remote server. This helper remains Windows-unexecuted here.

Every case retains `started.json`, a terminal `result.json` or `crash.json`, and logs. Failed/crashed cases remain failures and later cases continue. An interrupted case is recorded CRASH rather than rerun into a new claim. For a same-target resume, use the launcher with `-ResumeOwnedRun`; existing terminal cases stay immutable. A different target/user/output cannot reuse the receipt. Keep Sandbox open until all attended work and physical evidence are copied to the output folder. Exiting with code2 after automation can mean the attended qualification remains open; inspect recorded statuses.

## Optional Sandbox wrapper

`Prepare_Windows_Sandbox161.ps1` writes a `.wsb` configuration with a read-only bundle folder and one selected new writable results folder. Clipboard/printer redirection is disabled. Networking remains enabled for verified official dependency downloads. `Sandbox_Start161.ps1` uses the CMD setup helper and preserves setup failures before any test claim.

Sandbox requires an actual existing Windows host and supported Pro/Enterprise/Education edition plus virtualization and resources. It is not available on Home and is not a way to create a Windows host from Android. Its PowerShell startup also depends on the guest's normal script policy. Do not promise it is available before checking the host. Microsoft references: [overview](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/windows-sandbox-overview), [installation](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/windows-sandbox-install), [configuration](https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/windows-sandbox/windows-sandbox-configure-using-wsb-file).

## When no Windows host is connected

`private-ci/PRIVATE_CI_APPROVAL161.md` and the prepared workflow describe a concrete alternative: one owner-approved **private** repository, only the generic workflow, and two exact private release assets (runner ZIP and compiled installer). Nothing has been uploaded or published. The existing public repository cannot safely hold the current private material. The destination and private binary upload need explicit approval before any external change.

A same-repository pull request can trigger the workflow where the connector lacks a dispatch method. Repository creation and release-asset upload still require approved capabilities; they are not supplied by this bundle. The workflow refuses public repositories/fork PRs and needs no PAT or signing/cloud secrets. It uses the read-only job token, a standard `windows-latest` runner, a 45-minute cap and 7-day private result retention. Verify available included quota and a zero paid-spend limit before enabling; do not assume the account has unused free quota. Hard provider timeout can leave unfinished cases open, whose real partial evidence must be retained. The job covers functional UI candidates, not attended native speech/sleep/client/corpus/integration gates. Standard hosted runner disk/memory capacity is not a promise that the full original corpus fits.

GitHub references: [billing and usage](https://docs.github.com/en/actions/concepts/billing-and-usage), [standard hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners), [billing details](https://docs.github.com/en/billing/concepts/product-billing/github-actions).
