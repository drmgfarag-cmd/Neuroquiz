'use strict';
// No platform claim is made by this generic checkpoint scheduler.
// Production supplies the exact Windows worker and strict result validator.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
async function execute({definitions,output,owner,launch,validate,crashRecord,atomic,checkpoint}){
 const records=[];
 for(const def of definitions){
  const dir=path.join(output,def.id),result=path.join(dir,'result.json'),crash=path.join(dir,'crash.json');
  const expected={runId:owner.runId,targetSha256:owner.targetSha256,caseId:def.id};
  if(fs.existsSync(result)){records.push(validate(result,expected));await checkpoint(records);continue;}
  if(fs.existsSync(crash)){const r=JSON.parse(fs.readFileSync(crash));for(const k of Object.keys(expected))assert.equal(r[k],expected[k]);assert.equal(r.status,'CRASH');records.push(r);await checkpoint(records);continue;}
  if(fs.existsSync(dir)){
   const start=JSON.parse(fs.readFileSync(path.join(dir,'started.json')));for(const k of Object.keys(expected))assert.equal(start[k],expected[k]);
   const r=crashRecord(expected,{reason:'Prior worker interrupted without terminal result; evidence retained and case not retried.'});atomic(crash,r);records.push(r);await checkpoint(records);continue;
  }
  fs.mkdirSync(dir);atomic(path.join(dir,'started.json'),{...expected,atUtc:new Date().toISOString()});
  const outcome=await launch(def,dir,expected);
  if(fs.existsSync(result))records.push(validate(result,expected));
  else{const r=crashRecord(expected,outcome);atomic(crash,r);records.push(r);}
  await checkpoint(records);
 }
 return records;
}
module.exports={execute};
