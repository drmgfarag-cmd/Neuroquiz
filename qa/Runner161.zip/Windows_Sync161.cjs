'use strict';
/**
 * Explicit synthetic authenticated HTTP loopback counterpart for installed-Windows
 * UI acceptance. It is not evidence for a remote Android/server deployment.
 * Uses Node standard libraries only. Credentials are never included in snapshots.
 */
const http = require('node:http');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const childProcess = require('node:child_process');
const path = require('node:path');
const MAX_BYTES = 4 * 1024 * 1024, MAX_ROWS = 250;
const KEYS = Object.freeze({annotations:'id', questionStates:'questionId', cardStates:'cardId', sessions:'id', userFlashcards:'id', userCases:'id', corrections:'questionId', aiReviews:'questionId'});
const clone = value => JSON.parse(JSON.stringify(value));
const sha = value => crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const object = value => value && typeof value === 'object' && !Array.isArray(value) && [null, Object.prototype].includes(Object.getPrototypeOf(value));
const time = value => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const sequence = value => Number.isSafeInteger(value) && value >= 0;
const identity = value => typeof value === 'string' && value.length > 0 && value.length <= 1000 && !/[\u0000-\u001f]/.test(value);
function safe(value, depth = 0) {
  if (depth > 32) return false;
  if (value === null || ['string', 'boolean', 'undefined'].includes(typeof value)) return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (!object(value) && !Array.isArray(value)) return false;
  return Object.entries(value).every(([key, item]) => !['__proto__', 'prototype', 'constructor'].includes(key) && safe(item, depth + 1));
}
function validRecord(record) {
  if (!object(record) || !Object.hasOwn(KEYS, record.table) || !identity(record.id) || !time(record.updatedAt) || !safe(record)) return false;
  if (record.deleted !== undefined && typeof record.deleted !== 'boolean') return false;
  if (record.deleted) return record.row === undefined;
  const row = record.row;
  if (!object(row) || row[KEYS[record.table]] !== record.id || (row.updatedAt ?? row.createdAt ?? 0) !== record.updatedAt) return false;
  if (record.table === 'userFlashcards') {
    const media = items => Array.isArray(items) && items.every(item => object(item) && typeof item.file === 'string');
    return typeof row.front === 'string' && typeof row.back === 'string' && media(row.frontMedia) && media(row.backMedia);
  }
  // Other known personal-record families may accompany this one controlled card.
  // The production app is responsible for their complete schema. This counterpart
  // only echoes their valid identity/time envelope, and does not award their tests.
  return true;
}
function wire(record) {
  return {table:record.table, id:record.id, updatedAt:record.updatedAt, deleted:!!record.deleted,
    ...(record.deleted ? {} : {row:clone(record.row)})};
}
function syntheticCard({id = 'nq161-remote-' + crypto.randomUUID(), front, back, updatedAt = Date.now()} = {}) {
  const nonce = crypto.randomUUID();
  front ??= 'NQ161 received card ' + nonce;
  back ??= 'NQ161 received answer ' + nonce;
  return {table:'userFlashcards', id, updatedAt, row:{id, front, back, frontMedia:[], backMedia:[], sourceTags:['nq161-synthetic-loopback'], origin:'user', createdAt:updatedAt, updatedAt}};
}
async function startSyntheticSyncServer({token = crypto.randomBytes(32).toString('hex'), remoteCard = syntheticCard()} = {}) {
  assert(typeof token === 'string' && token.length >= 16, 'A bounded nonempty synthetic credential is required');
  assert(validRecord(remoteCard) && remoteCard.table === 'userFlashcards' && !remoteCard.deleted, 'Valid separate synthetic personal card required');
  const serverId = 'nq161-loopback-' + crypto.randomUUID();
  const records = new Map(), received = [], requests = [], versions = [];
  let seq = 0;
  function merge(record) {
    const value = wire(record), key = value.table + ':' + value.id, prior = records.get(key);
    if (prior && !(value.updatedAt > prior.record.updatedAt || value.updatedAt === prior.record.updatedAt && value.deleted && !prior.record.deleted)) return;
    const entry = {seq:++seq, record:value};
    records.set(key, entry); versions.push(entry);
  }
  merge(remoteCard);
  const expectedAuth = Buffer.from('Bearer ' + token);
  function authorized(value) {
    const actual = Buffer.from(typeof value === 'string' ? value : '');
    return actual.length === expectedAuth.length && crypto.timingSafeEqual(actual, expectedAuth);
  }
  const server = http.createServer(async (req, res) => {
    const log = {method:req.method, path:'', atUtc:new Date().toISOString(), authenticated:false, status:0, offeredChanges:0, returnedChanges:0};
    requests.push(log);
    const origin = req.headers.origin;
    const allowedOrigin = origin === 'app://neuroquiz' ? origin : undefined;
    function send(status, body) {
      log.status = status;
      if (res.destroyed || res.writableEnded) return;
      res.writeHead(status, {'Content-Type':'application/json', 'Cache-Control':'no-store', Connection:'close',
        'Access-Control-Allow-Headers':'Content-Type, Authorization', 'Access-Control-Allow-Methods':'POST, OPTIONS, GET',
        ...(allowedOrigin ? {'Access-Control-Allow-Origin':allowedOrigin} : {}),
        ...(allowedOrigin && req.headers['access-control-request-private-network'] === 'true' ? {'Access-Control-Allow-Private-Network':'true'} : {})});
      res.end(body === undefined ? '' : JSON.stringify(body));
    }
    try { log.path = new URL(req.url || '/', 'http://127.0.0.1').pathname; }
    catch { return send(400, {error:'Invalid local request path'}); }
    if (origin && !allowedOrigin) return send(403, {error:'Only the installed app origin is allowed'});
    if (req.method === 'OPTIONS') return send(204);
    if (req.method === 'GET' && log.path === '/health') return send(200, {ok:true, protocol:2, syntheticCounterpart:true});
    log.authenticated = authorized(req.headers.authorization);
    if (!log.authenticated) return send(401, {error:'Authentication required'});
    if (req.method !== 'POST' || log.path !== '/sync') return send(404, {error:'Not found'});
    if (requests.length > 1000) return send(429, {error:'Synthetic run request bound exceeded'});
    try {
      const text = await new Promise((resolve, reject) => {
        const chunks = []; let bytes = 0, done = false;
        const timer = setTimeout(() => finish(Error('Request body timed out')), 15000);
        const finish = error => { if (done) return; done = true; clearTimeout(timer); if (error) reject(error); else resolve(Buffer.concat(chunks).toString('utf8')); };
        if (Number(req.headers['content-length']) > MAX_BYTES) { req.resume(); finish(Error('Request size limit')); return; }
        req.on('data', chunk => { if (done) return; bytes += chunk.length; if (bytes > MAX_BYTES) { req.resume(); finish(Error('Request size limit')); } else chunks.push(chunk); });
        req.on('end', () => finish());
        req.on('error', () => finish(Error('Request disconnected')));
        req.on('aborted', () => finish(Error('Request disconnected')));
      });
      const body = JSON.parse(text);
      if (!object(body) || body.protocol !== 2 || !sequence(body.since) || !Array.isArray(body.changes) || body.changes.length > MAX_ROWS || !body.changes.every(validRecord) ||
          (body.device !== undefined && (typeof body.device !== 'string' || body.device.length > 60)) ||
          (body.pull !== undefined && typeof body.pull !== 'boolean')) return send(400, {error:'Invalid synthetic protocol envelope'});
      if (body.serverId !== undefined && body.serverId !== serverId) return send(409, {error:'Counterpart identity changed'});
      if (body.since > seq || body.until !== undefined && (!sequence(body.until) || body.until < body.since || body.until > seq)) return send(400, {error:'Invalid synthetic cursor'});
      // This is the success counterpart, not a simulation of conflict resolution.
      if (body.inspectKeys !== undefined || body.resolution !== undefined) return send(400, {error:'Conflict workflow is outside this synthetic success case'});
      log.offeredChanges = body.changes.length;
      for (const record of body.changes) { received.push(wire(record)); merge(record); }
      if (body.pull === false) return send(200, {protocol:2, serverId, seq:body.since, until:seq, headSeq:seq, more:false, changes:[], rejectedKeys:[]});
      const until = body.until ?? seq, eligible = versions.filter(row => row.seq > body.since && row.seq <= until);
      const page = eligible.slice(0, MAX_ROWS), more = eligible.length > page.length;
      const cursor = more ? page[page.length - 1].seq : until;
      log.returnedChanges = page.length;
      log.since = body.since; log.until = until; log.headSeq = seq;
      return send(200, {protocol:2, serverId, seq:cursor, until, headSeq:seq, more, changes:page.map(row => wire(row.record))});
    } catch { return send(400, {error:'Invalid or interrupted synthetic request'}); }
  });
  server.requestTimeout = 30000; server.headersTimeout = 15000; server.keepAliveTimeout = 1000;
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const url = 'http://127.0.0.1:' + server.address().port;
  const api = {
    url, serverId, remoteCard:clone(wire(remoteCard)),
    snapshot() { return {counterpart:'synthetic authenticated HTTP loopback', url, serverId, headSeq:seq, requestCount:requests.length,
      authenticatedPostCount:requests.filter(row => row.method === 'POST' && row.authenticated).length,
      receivedRecordCount:received.length, receivedRecordIdentities:received.map(row => ({table:row.table, id:row.id, updatedAt:row.updatedAt, recordSha256:sha(row)})),
      requests:clone(requests), credentialValuesIncluded:false, actualRemoteAndroidSyncAccepted:false}; },
    receivedRecords() { return clone(received); },
    async close() { if (!server.listening) return; server.closeIdleConnections?.(); await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); }
  };
  Object.defineProperty(api, 'token', {value:token, enumerable:false});
  return api;
}
function watchOwnedLoopbackPermission(appProcessId) {
  assert.equal(process.platform, 'win32', 'The native permission watcher requires actual Windows');
  assert(Number.isSafeInteger(appProcessId) && appProcessId > 0, 'Actual owned Electron PID required');
  const format = 'neuroquiz-owned-windows-loopback-permission161-v1';
  const title = 'NeuroQuiz permission', message = 'Allow NeuroQuiz to connect to your local sync server?';
  const started = Date.now(), wallLimit = 35000;
  let stdout = '', stderr = '', stopped = false, timedOut = false, outputExceeded = false, launchError;
  const child = childProcess.spawn('powershell.exe', ['-NoProfile', '-File', path.join(__dirname, 'Allow_Windows_Loopback161.ps1'),
    '-AppProcessId', String(appProcessId), '-WaitSeconds', '30'], {stdio:['ignore', 'pipe', 'pipe'], windowsHide:true});
  const result = new Promise(resolve => {
    const finish = (exitCode, signal) => {
      if (stopped) return;
      stopped = true; clearTimeout(timer);
      let proof;
      try {
        assert(!launchError && !timedOut && !outputExceeded, 'Native observer did not complete normally');
        proof = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
        assert.equal(proof.format, format); assert.equal(proof.platform, 'win32'); assert.equal(proof.appProcessId, appProcessId);
        assert(['ALLOWED', 'NOT_SHOWN', 'REFUSED', 'ERROR'].includes(proof.status));
        assert.equal(proof.exactTitleRequired, title); assert.equal(proof.exactMessageRequired, message);
        assert.equal(proof.exactButtonRequired, 'Allow'); assert.equal(proof.unrelatedWindowsInvoked, false);
        assert.equal(proof.waitLimitMilliseconds, 30000);
        if (proof.status === 'ALLOWED') { assert.equal(proof.invoked, true); assert.equal(proof.exactMessageObserved, true); }
        if (proof.status === 'NOT_SHOWN') { assert.equal(proof.invoked, false); assert.equal(proof.sameTitleOwnedWindowsObserved, 0); }
      } catch (error) {
        proof = {format, platform:process.platform, appProcessId, status:timedOut ? 'WATCHER_TIMEOUT' : 'WATCHER_ERROR',
          invoked:false, reason:launchError || (outputExceeded ? 'Native observer output exceeded its fixed bound' : String(error.message || error)),
          stderr:stderr.slice(0, 4096), credentialValuesIncluded:false};
      }
      resolve({...proof, watcherExitCode:exitCode, watcherSignal:signal || null, watcherWallLimitMilliseconds:wallLimit,
        watcherElapsedMilliseconds:Date.now() - started, noPermissionOrDialogHooksUsed:true});
    };
    const timer = setTimeout(() => { timedOut = true; try { child.kill(); } catch {} finish(null, 'bounded-timeout'); }, wallLimit);
    child.stdout.on('data', chunk => { stdout += chunk.toString('utf8'); if (stdout.length > 65536) { outputExceeded = true; try { child.kill(); } catch {} finish(null, 'output-limit'); } });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk.toString('utf8')).slice(0, 4096); });
    child.once('error', error => { launchError = String(error.message || error); finish(null, null); });
    child.once('close', finish);
  });
  return {result};
}
async function body(c) {
  assert(c && c.page && typeof c.switchProfile === 'function' && typeof c.read === 'function' && typeof c.artifact === 'function', 'Actual installed UI context required');
  const page = c.page, nonce = crypto.randomUUID(), localFront = 'NQ161 sync sent card ' + nonce, localBack = 'NQ161 sync sent answer ' + nonce;
  const remote = syntheticCard({id:'nq161-sync-remote-' + nonce, front:'NQ161 sync received card ' + nonce, back:'NQ161 sync received answer ' + nonce});
  const peer = await startSyntheticSyncServer({remoteCard:remote});
  let savedDevice = '', preferencesConfigured = false, permissionWatcher, permissionProof;
  const retainPermissionProof = async () => {
    if (!permissionWatcher || permissionProof) return permissionProof;
    permissionProof = await permissionWatcher.result;
    c.artifact('configured-localhost-native-permission.json', permissionProof);
    return permissionProof;
  };
  const go = async route => { await page.goto('app://neuroquiz/index.html#' + route); await page.locator('main h1').waitFor({state:'visible'}); };
  try {
    await c.switchProfile('My profile');
    const owner = await c.read(['meta']);
    assert.equal(owner.tables.meta.find(row => row.key === 'profile:active')?.value || 'default', 'default', 'Sync must use the actual default owning profile');
    await go('/flashcards');
    await page.locator('main').getByRole('button', {name:'Create', exact:true}).click();
    await page.locator('main').getByLabel('Front (markdown supported)', {exact:true}).fill(localFront);
    await page.locator('main').getByLabel('Back', {exact:true}).fill(localBack);
    await page.locator('main').getByRole('button', {name:'Save card', exact:true}).click();
    await page.locator('main').getByText(localFront, {exact:false}).first().waitFor({state:'visible'});
    const localRows = await c.read(['userFlashcards']);
    const local = localRows.tables.userFlashcards.filter(row => row.front === localFront && row.back === localBack);
    assert.equal(local.length, 1, 'Exactly one personal card must be committed by normal UI');
    await go('/settings');
    const section = page.getByRole('region', {name:'Optional sync', exact:true});
    await section.getByRole('heading', {name:'Optional sync', exact:true}).waitFor({state:'visible'});
    const address = section.getByLabel('Sync server URL', {exact:true}), device = section.getByLabel('Device name', {exact:true}), credential = section.getByLabel('Sync token', {exact:true});
    const previous = await address.inputValue();
    if (previous.trim()) throw Error('A preconfigured endpoint is present; this synthetic case requires fresh default sync preferences. No external endpoint was contacted.');
    savedDevice = await device.inputValue();
    await address.fill(peer.url);
    await device.fill('NQ161 Windows loopback acceptance');
    await credential.fill(peer.token);
    await section.getByRole('button', {name:'Save sync preferences', exact:true}).click();
    await section.getByText('Sync preferences saved on this device. No records were sent.', {exact:true}).waitFor({state:'visible'});
    preferencesConfigured = true;
    assert.equal(peer.snapshot().requestCount, 0, 'Saving preferences must not contact the server');
    permissionWatcher = watchOwnedLoopbackPermission(c.appPid);
    const clickStartedAt = Date.now();
    await section.getByRole('button', {name:'Sync now', exact:true}).click();
    const status = section.getByRole('status').filter({hasText:/^Sync complete:/});
    await status.waitFor({state:'visible', timeout:45000});
    const statusText = (await status.innerText()).trim();
    const match = /^Sync complete: (\d+) sent, (\d+) received, (\d+) applied\. (\d+) conflicts need review\.$/.exec(statusText);
    assert(match, 'The UI must expose exact committed sync outcome counts');
    const nativePermission = await retainPermissionProof();
    assert(nativePermission.watcherExitCode === 0 && ['ALLOWED', 'NOT_SHOWN'].includes(nativePermission.status),
      'Native permission observation must complete safely; NOT_SHOWN is accepted only alongside successful real UI sync');
    const [sent, received, applied, rejected] = match.slice(1).map(Number);
    assert(sent >= 1 && received >= 1 && applied >= 1 && rejected === 0, 'Nonempty sent, received and applied outcomes with no synthetic conflicts required');
    const offered = peer.receivedRecords().filter(record => record.table === 'userFlashcards' && record.id === local[0].id && record.row?.front === localFront && record.row?.back === localBack);
    assert.equal(offered.length, 1, 'Authenticated server must actually receive the exact locally-created personal card');
    const snapshot = peer.snapshot();
    assert(snapshot.authenticatedPostCount >= 3, 'Hello, nonempty push and pull must reach the real loopback server');
    assert(snapshot.requests.every(request => Date.parse(request.atUtc) >= clickStartedAt), 'A request preceded the explicit Sync now action');
    assert.equal(sent, snapshot.receivedRecordCount, 'UI sent count differs from actual offered wire records');
    assert.equal(received, snapshot.requests.reduce((sum, request) => sum + request.returnedChanges, 0), 'UI received count differs from actual returned wire records');
    const after = await c.read(['userFlashcards']);
    const inbound = after.tables.userFlashcards.find(row => row.id === remote.id);
    assert(inbound && inbound.front === remote.row.front && inbound.back === remote.row.back, 'The exact separate server card must be committed locally');
    assert(after.tables.userFlashcards.some(row => row.id === local[0].id && row.front === localFront && row.back === localBack), 'Sync must retain the sent local card');
    await go('/flashcards?tab=browse');
    await page.locator('main').getByLabel('Filter cards', {exact:true}).fill(remote.row.front);
    const row = page.locator('main .list-item > button[aria-expanded]').filter({hasText:remote.row.front});
    await row.waitFor({state:'visible'});
    assert.equal(await row.count(), 1, 'Received card search must return its exact source identity once');
    await row.click();
    await page.locator('main').getByText(remote.row.back, {exact:true}).waitFor({state:'visible'});
    const proof = {counterpart:'explicit synthetic authenticated Node HTTP loopback', defaultProfileSelectedThroughUI:true,
      preferencesSavedWithoutRequests:true, exactLocalCardReceived:{id:local[0].id, front:localFront, rowSha256:sha(local[0])},
      exactRemoteCardApplied:{id:remote.id, front:remote.row.front, rowSha256:sha(inbound)},
      receivedCardFoundAndBackReadThroughUI:true, outcome:{sent, received, applied, rejected}, uiStatus:statusText,
      nativeLoopbackPermission:{status:nativePermission.status, appProcessId:nativePermission.appProcessId, invoked:nativePermission.invoked},
      server:snapshot, credentialValuesIncluded:false, actualRemoteAndroidSyncAccepted:false,
      scope:'Actual installed Windows UI and loopback transport only; not remote deployment, remote Android sync, conflict resolution or external AI acceptance.'};
    c.artifact('configured-localhost-sync-proof.json', proof);
    return proof;
  } catch (error) {
    // Playwright call logs may contain fill() arguments; redact this synthetic
    // credential before the worker persists an error or stack.
    throw new Error(String(error.stack || error).replaceAll(peer.token, '[synthetic credential redacted]'));
  } finally {
    await retainPermissionProof();
    let cleanupFailure;
    if (preferencesConfigured) {
      try {
        await go('/settings');
        const section = page.getByRole('region', {name:'Optional sync', exact:true});
        await section.getByLabel('Sync server URL', {exact:true}).fill('');
        await section.getByLabel('Device name', {exact:true}).fill(savedDevice);
        await section.getByLabel('Sync token', {exact:true}).fill('');
        await section.getByRole('button', {name:'Save sync preferences', exact:true}).click();
        await section.getByText('Sync preferences saved on this device. No records were sent.', {exact:true}).waitFor({state:'visible'});
      } catch (error) { cleanupFailure = new Error('Normal UI sync-preference cleanup did not complete: ' + String(error.message || error).replaceAll(peer.token, '[synthetic credential redacted]')); if (typeof c.artifact === 'function') c.artifact('configured-localhost-sync-cleanup-error.json', {error:cleanupFailure.message}); }
    }
    c.artifact('configured-localhost-sync-server-final.json', peer.snapshot());
    await peer.close();
    if (cleanupFailure) throw cleanupFailure;
  }
}
module.exports = {body, startSyntheticSyncServer, syntheticCard, watchOwnedLoopbackPermission};
