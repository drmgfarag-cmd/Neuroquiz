(() => {
  'use strict';
  if (window.__nqEnh157) return 'enhancement157-ready';
  const clone = value => JSON.parse(JSON.stringify(value));
  const canonical = value => JSON.stringify(value, (_, x) => x && !Array.isArray(x) && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, x[k]])) : x);
  const equal = (a, b) => canonical(a) === canonical(b);
  const without = (value, keys) => Object.fromEntries(Object.entries(value).filter(([key]) => !keys.includes(key)));
  const visible = e => !!e && e.isConnected && e.getClientRects().length > 0 && !e.closest('[hidden],[inert],[aria-hidden="true"]');
  const required = (value, why) => { if (!value) throw Error(why); };
  const api = {
    canonical, equal, visible,
    read() {
      api.snapshot = { pending: true };
      const open = indexedDB.open('neuroquiz');
      open.onupgradeneeded = () => { open.transaction.abort(); api.snapshot = { error: 'Expected existing source database; no creation permitted' }; };
      open.onerror = () => { api.snapshot = { error: 'Readonly database open failed' }; };
      open.onsuccess = () => {
        const db = open.result, names = ['meta', 'cardStates', 'studyEvents', 'tombstones'];
        try {
          const tx = db.transaction(names, 'readonly'), out = { tables: {} };
          for (const name of names) {
            const request = tx.objectStore(name).getAll(undefined, 2001);
            request.onsuccess = () => { if (request.result.length > 2000) out.error = 'Complete synthetic bound exceeded: ' + name; else out.tables[name] = request.result; };
          }
          tx.oncomplete = () => {
            db.close();
            if (out.error || Object.keys(out.tables).length !== names.length) { api.snapshot = { error: out.error || 'Incomplete readonly witness' }; return; }
            out.profileId = out.tables.meta.find(r => r.key === 'profile:active')?.value || 'default';
            out.epoch = out.tables.meta.find(r => r.key === 'study.epoch:' + out.profileId)?.value || 'initial';
            out.block = out.tables.meta.find(r => r.key === 'study.card-block:' + out.profileId)?.value || null;
            out.undo = out.tables.meta.find(r => r.key === 'study.card-undo:' + out.profileId)?.value || null;
            api.snapshot = out;
          };
          tx.onerror = tx.onabort = () => { db.close(); api.snapshot = { error: 'Readonly witness aborted' }; };
        } catch (error) { db.close(); api.snapshot = { error: String(error) }; }
      };
      return 'started';
    },
    undoProof(before, graded, restored, displayedId) {
      required(before?.block && graded?.undo && restored?.block, 'All three complete owned snapshots required');
      const b = before.block, g = graded.block, r = restored.block, receipt = graded.undo, prior = receipt.beforeBlock;
      required(before.profileId === graded.profileId && graded.profileId === restored.profileId && before.epoch === graded.epoch && graded.epoch === restored.epoch, 'Owned profile/epoch changed');
      required([b, g, r, prior].every(v => v.id === b.id && v.profileId === before.profileId && v.epoch === before.epoch), 'Block source owner/id changed');
      required(b.reviews === 0 && g.reviews === 1 && r.reviews === 0 && b.total === 2 && g.total === 2 && r.total === 2 && b.pending.length === 2 && g.pending.length === 1 && r.pending.length === 2, 'Actual Cram block deltas differ');
      required(receipt.itemId === displayedId && receipt.reviewId === g.lastOperation && receipt.afterRevision === g.revision && prior.reviews === 0, 'Undo receipt does not bind the exact displayed rating');
      const selected = b.pending.find(v => v.id === displayedId), priorSelected = prior.pending.find(v => v.id === displayedId), restoredSelected = r.pending.find(v => v.id === displayedId);
      required(selected && priorSelected && restoredSelected && selected.operationId === receipt.reviewId && restoredSelected.operationId !== receipt.reviewId, 'Restored operation is not fresh or source selection is absent');
      required(equal(without(b, ['pending']), without(prior, ['pending'])) && equal(b.pending.filter(v => v.id !== displayedId), prior.pending.filter(v => v.id !== displayedId)), 'Captured beforeBlock changed an unrelated queue row');
      required(equal(without(selected, ['timeMs']), without(priorSelected, ['timeMs'])) && Number.isSafeInteger(priorSelected.timeMs) && priorSelected.timeMs >= selected.timeMs, 'Captured active time/source selection is invalid');
      required(equal(without(r, ['revision', 'updatedAt', 'pending']), without(prior, ['revision', 'updatedAt', 'pending'])) && r.revision !== g.revision && r.revision !== b.revision, 'Restored block metadata differs from the original operation');
      required(equal(r.pending.map(v => v.id), prior.pending.map(v => v.id)) && equal(r.pending.filter(v => v.id !== displayedId), prior.pending.filter(v => v.id !== displayedId)), 'Undo reordered or altered unrelated source queue entries');
      required(equal(without(restoredSelected, ['operationId', 'state']), without(priorSelected, ['operationId', 'state'])), 'Undo changed restored source fields or accumulated active time');
      const oldEvents = before.tables.studyEvents, gradeEvents = graded.tables.studyEvents, afterEvents = restored.tables.studyEvents;
      required(oldEvents.every(e => gradeEvents.some(v => equal(e, v))) && gradeEvents.every(e => afterEvents.some(v => equal(e, v))), 'An immutable earlier/rating event was changed or removed');
      const rating = gradeEvents.filter(e => !oldEvents.some(v => v.id === e.id));
      const undo = afterEvents.filter(e => !gradeEvents.some(v => v.id === e.id));
      required(rating.length === 1 && rating[0].id === receipt.reviewId && rating[0].kind === 'card-review' && rating[0].itemId === displayedId && rating[0].profileId === before.profileId && rating[0].epoch === before.epoch, 'One exact owned rating event required');
      required(undo.length === 1 && undo[0].kind === 'card-review-undo' && undo[0].reviewId === rating[0].id && undo[0].itemId === displayedId && undo[0].profileId === before.profileId && undo[0].epoch === before.epoch && undo[0].counted === false, 'Exactly one owned uncounted Undo event required');
      required(restored.undo === null, 'Consumed Undo receipt remains available');
      required(equal(before.tables.cardStates.filter(v => v.cardId !== displayedId), restored.tables.cardStates.filter(v => v.cardId !== displayedId)), 'An unrelated card state changed');
      const oldState = before.tables.cardStates.find(v => v.cardId === displayedId) || null, gradeState = graded.tables.cardStates.find(v => v.cardId === displayedId) || null, state = restored.tables.cardStates.find(v => v.cardId === displayedId) || null;
      required(equal(oldState, receipt.beforeState) && equal(gradeState, receipt.afterState), 'Receipt before/after state is not the actual persisted state');
      required(oldState ? state && equal(without(oldState, ['updatedAt']), without(state, ['updatedAt'])) && state.updatedAt > gradeState.updatedAt : state === null, 'Undo did not restore the prior scheduling state with its required fresh timestamp');
      const tombKey = 'cardStates:' + displayedId, otherTombs = rows => rows.filter(v => v.key !== tombKey);
      required(equal(otherTombs(before.tables.tombstones), otherTombs(graded.tables.tombstones)) && equal(otherTombs(graded.tables.tombstones), otherTombs(restored.tables.tombstones)), 'An unrelated deletion/tombstone record changed');
      if (before.profileId === 'default' && oldState === null) {
        const own = restored.tables.tombstones.filter(v => v.key === tombKey), priorTombs = graded.tables.tombstones.filter(v => v.key === tombKey);
        required(own.length === 1 && priorTombs.length <= 1 && Object.keys(own[0]).sort().join(',') === 'id,key,table,updatedAt' && own[0].id === displayedId && own[0].table === 'cardStates' && Number.isSafeInteger(own[0].updatedAt) && own[0].updatedAt > gradeState.updatedAt && (!priorTombs.length || own[0].updatedAt > priorTombs[0].updatedAt), 'Default absent-state Undo lacks its exact fresh own deletion tombstone');
      } else required(equal(graded.tables.tombstones, restored.tables.tombstones), 'This owned Undo cannot alter any tombstone');
      required(equal(graded.tables.meta.filter(v => !['study.card-block:' + before.profileId, 'study.card-undo:' + before.profileId].includes(v.key)), restored.tables.meta.filter(v => !['study.card-block:' + before.profileId, 'study.card-undo:' + before.profileId].includes(v.key))), 'Undo changed unrelated metadata');
      return { exactOwnedSnapshotRollback: true, originalRatingRetainedByteExact: true, exactlyOneUncountedUndo: true, sourceQueueRestored: true, receiptConsumed: true, lowLevelStaleOrForeignInvocationClaimed: false, displayedId, reviewId: rating[0].id, undoEventId: undo[0].id, blockId: b.id, profileId: before.profileId, epoch: before.epoch };
    },
    workerStart() {
      required(typeof Worker === 'function' && !api.workerObserver, 'Native Worker or exclusive observer unavailable');
      const original = Worker.prototype.postMessage, instances = new WeakMap(), listeners = [], events = [], state = { events, overflow: false }, clock = () => performance.now();
      let serial = 0;
      const add = value => { if (events.length >= 300) { state.overflow = true; return; } events.push(value); };
      const wrapped = function (...args) {
        const message = args[0];
        if (message && ['suggest', 'cancel'].includes(message.type) && Number.isSafeInteger(message.id)) {
          if (!instances.has(this)) {
            const token = ++serial; instances.set(this, token);
            const listener = event => {
              const value = event.data;
              if (!value || !Number.isSafeInteger(value.id)) return;
              const encoded = JSON.stringify(value);
              if (encoded.length > 65536) { state.overflow = true; return; }
              add({ kind: 'message', worker: token, at: clock(), trusted: event.isTrusted === true, value: clone(value) });
            };
            this.addEventListener('message', listener); listeners.push([this, listener]);
          }
          add({ kind: 'send', worker: instances.get(this), at: clock(), value: clone(message) });
        }
        // Exact native Worker method, same receiver and argument objects; no delay, replacement, error suppression or synthetic completion.
        return Reflect.apply(original, this, args);
      };
      Worker.prototype.postMessage = wrapped;
      api.workerObserver = { state, original, wrapped, listeners };
      return true;
    },
    workerRows() { required(api.workerObserver, 'Worker observer absent'); return clone(api.workerObserver.state); },
    workerStop() {
      const observer = api.workerObserver; if (!observer) return true;
      const unchanged = Worker.prototype.postMessage === observer.wrapped;
      if (unchanged) Worker.prototype.postMessage = observer.original;
      for (const [worker, listener] of observer.listeners) worker.removeEventListener('message', listener);
      api.workerObserver = null;
      required(unchanged, 'Worker prototype changed outside this observer; restoration refused');
      return true;
    },
    queryView() {
      const inputs = [...document.querySelectorAll('input[aria-label="Search all content"]')].filter(visible);
      required(inputs.length === 1, 'Exact current search input is not unique');
      const input = inputs[0], buttons = [...document.querySelectorAll('ul[aria-label="Offline search suggestions"] button')].filter(visible);
      return { query: input.value, focusedInput: document.activeElement === input, focusedChoice: buttons.indexOf(document.activeElement), choices: buttons.map(e => ({ text: e.textContent.trim(), label: e.getAttribute('aria-label') })), hash: location.hash };
    },
    watchQueryChange(expected) {
      const inputs = [...document.querySelectorAll('input[aria-label="Search all content"]')].filter(visible);
      required(inputs.length === 1 && typeof expected === 'string' && expected.length <= 1000, 'Exact bounded source query change required');
      if (api.queryChangeListener) api.queryChangeListener.node.removeEventListener('input', api.queryChangeListener.listener, true);
      const node = inputs[0]; api.queryChange = { observed: false, expected };
      const listener = event => {
        if (event.target !== node || !visible(node) || node.value !== expected) return;
        api.queryChange = { observed: true, value: node.value, at: performance.now(), hash: location.hash };
        node.removeEventListener('input', listener, true); api.queryChangeListener = null;
      };
      node.addEventListener('input', listener, true); api.queryChangeListener = { node, listener }; return true;
    },
    stopQueryChange() {
      if (api.queryChangeListener) api.queryChangeListener.node.removeEventListener('input', api.queryChangeListener.listener, true);
      api.queryChangeListener = null; return true;
    },
    focusQuery() { const inputs = [...document.querySelectorAll('input[aria-label="Search all content"]')].filter(visible); required(inputs.length === 1 && !inputs[0].disabled, 'Search input unavailable'); inputs[0].focus(); return document.activeElement === inputs[0]; },
    capturePosition(selector) {
      const nodes = [...document.querySelectorAll(selector)].filter(visible); required(nodes.length === 1 && !nodes[0].disabled, 'Exact source field unavailable');
      const node = nodes[0]; node.scrollIntoView({ block: 'center', behavior: 'instant' }); node.focus({ preventScroll: true });
      required(document.activeElement === node && scrollY > 100, 'Actual nonzero document scroll/focus cannot be observed');
      api.position = { node, x: scrollX, y: scrollY, pathname: location.hash.split('?')[0], hash: location.hash };
      return { x: scrollX, y: scrollY, pathname: api.position.pathname, hash: location.hash };
    },
    positionHeld() { const p = api.position; return !!p && p.node.isConnected && document.activeElement === p.node && location.hash.split('?')[0] === p.pathname && Math.abs(scrollX - p.x) <= 2 && Math.abs(scrollY - p.y) <= 2; },
    imageRead(selector) {
      const images = [...document.querySelectorAll(selector)].filter(visible); required(images.length === 1 && images[0].complete && images[0].naturalWidth > 0, 'Exact original image not decoded');
      api.image = { pending: true }; const img = images[0], source = img.currentSrc || img.src;
      fetch(source).then(r => { if (!r.ok) throw Error('Original fetch refused'); return r.arrayBuffer(); }).then(async bytes => {
        if (bytes.byteLength > 65536) throw Error('Synthetic original exceeds declared64KiB bound');
        const hash = await crypto.subtle.digest('SHA-256', bytes);
        api.image = { bytes: bytes.byteLength, sha256: [...new Uint8Array(hash)].map(v => v.toString(16).padStart(2, '0')).join(''), width: img.naturalWidth, height: img.naturalHeight, alt: img.alt };
      }).catch(error => { api.image = { error: String(error) }; }); return 'reading';
    }
  };
  window.__nqEnh157 = api;
  return 'enhancement157-ready';
})()
