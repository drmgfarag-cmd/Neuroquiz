'use strict';
// These tests execute the explicit synthetic Node loopback counterpart only.
// They do not execute Electron or award any installed-Windows/Android acceptance.
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {startSyntheticSyncServer, syntheticCard} = require('../Windows_Sync161.cjs');
async function peerFor(t) {
  const peer = await startSyntheticSyncServer({token:'nq161-host-contract-' + crypto.randomUUID()});
  t.after(async () => { await peer.close(); });
  return peer;
}
async function request(peer, body, {wrongToken = false} = {}) {
  const response = await fetch(peer.url + '/sync', {
    method:'POST',
    headers:{'Content-Type':'application/json', Authorization:'Bearer ' + (wrongToken ? 'invalid-host-test-credential' : peer.token)},
    body:JSON.stringify(body)
  });
  return {status:response.status, body:await response.json()};
}
const envelope = changes => ({protocol:2, since:0, changes, device:'host-protocol-contract', pull:false});
function localCard() {
  return syntheticCard({id:'nq161-host-sent-' + crypto.randomUUID(), front:'NQ161 host sent front', back:'NQ161 host sent back'});
}
function validCardWire(record) {
  return record && record.table === 'userFlashcards' && typeof record.id === 'string' && record.id.length &&
    Number.isFinite(record.updatedAt) && record.updatedAt >= 0 && record.deleted === false &&
    record.row && record.row.id === record.id && record.row.updatedAt === record.updatedAt &&
    typeof record.row.front === 'string' && typeof record.row.back === 'string' &&
    Array.isArray(record.row.frontMedia) && Array.isArray(record.row.backMedia);
}
test('host counterpart starts on a dynamic loopback port without sending any request', async t => {
  const peer = await peerFor(t), address = new URL(peer.url);
  assert.equal(address.protocol, 'http:');
  assert.equal(address.hostname, '127.0.0.1');
  assert(Number(address.port) > 0);
  assert.equal(peer.snapshot().requestCount, 0);
  assert.equal(peer.snapshot().headSeq, 1);
  assert(validCardWire(peer.remoteCard));
  assert.equal(peer.snapshot().actualRemoteAndroidSyncAccepted, false);
});
test('unauthenticated nonempty push is refused without publishing its record', async t => {
  const peer = await peerFor(t), local = localCard();
  const result = await request(peer, envelope([local]), {wrongToken:true});
  assert.equal(result.status, 401);
  assert.equal(peer.snapshot().headSeq, 1);
  assert.equal(peer.receivedRecords().length, 0);
  assert.equal(peer.snapshot().authenticatedPostCount, 0);
});
test('authenticated hello returns a stable protocol2 identity and no payload for pull=false', async t => {
  const peer = await peerFor(t);
  const first = await request(peer, envelope([]));
  const second = await request(peer, envelope([]));
  assert.equal(first.status, 200);
  assert.equal(first.body.protocol, 2);
  assert.equal(first.body.serverId, peer.serverId);
  assert.equal(second.body.serverId, first.body.serverId);
  assert.equal(first.body.seq, 0);
  assert.equal(first.body.until, 1);
  assert.equal(first.body.headSeq, 1);
  assert.equal(first.body.more, false);
  assert.deepEqual(first.body.changes, []);
});
test('authenticated nonempty push reaches the counterpart with the exact personal-card row', async t => {
  const peer = await peerFor(t), local = localCard();
  const result = await request(peer, {...envelope([local]), serverId:peer.serverId});
  assert.equal(result.status, 200);
  assert.equal(result.body.headSeq, 2);
  assert.deepEqual(result.body.changes, []);
  const rows = peer.receivedRecords();
  assert.equal(rows.length, 1);
  assert.equal(rows[0].id, local.id);
  assert.deepEqual(rows[0].row, local.row);
  assert.equal(rows[0].deleted, false);
  assert.equal(peer.snapshot().receivedRecordCount, 1);
});
test('a real protocol pull contains the distinct seed card and echoed local card with final cursor', async t => {
  const peer = await peerFor(t), local = localCard();
  const hello = await request(peer, envelope([]));
  await request(peer, {...envelope([local]), serverId:hello.body.serverId});
  const result = await request(peer, {protocol:2, since:0, until:2, changes:[], device:'host-protocol-contract', serverId:hello.body.serverId});
  assert.equal(result.status, 200);
  assert.equal(result.body.seq, 2);
  assert.equal(result.body.until, 2);
  assert.equal(result.body.headSeq, 2);
  assert.equal(result.body.more, false);
  assert.equal(result.body.changes.length, 2);
  assert(result.body.changes.every(validCardWire));
  assert.deepEqual(new Set(result.body.changes.map(row => row.id)), new Set([local.id, peer.remoteCard.id]));
  assert.deepEqual(result.body.changes.find(row => row.id === peer.remoteCard.id).row, peer.remoteCard.row);
  assert.equal(peer.snapshot().authenticatedPostCount, 3);
  assert.equal(peer.snapshot().requests.reduce((sum, row) => sum + row.returnedChanges, 0), 2);
});
test('invalid cursor is rejected before otherwise valid outgoing changes can be published', async t => {
  const peer = await peerFor(t);
  const result = await request(peer, {...envelope([localCard()]), since:999});
  assert.equal(result.status, 400);
  assert.equal(peer.snapshot().headSeq, 1);
  assert.equal(peer.receivedRecords().length, 0);
});
test('a foreign server identity is refused without publishing a valid offered card', async t => {
  const peer = await peerFor(t);
  const result = await request(peer, {...envelope([localCard()]), serverId:'different-synthetic-server'});
  assert.equal(result.status, 409);
  assert.equal(peer.snapshot().headSeq, 1);
  assert.equal(peer.receivedRecords().length, 0);
});
test('credential values remain absent from serializable helper and authenticated request snapshots', async t => {
  const peer = await peerFor(t);
  await request(peer, envelope([localCard()]));
  assert(!JSON.stringify(peer).includes(peer.token), 'Serializable helper must not expose a credential value');
  assert(!JSON.stringify(peer.snapshot()).includes(peer.token), 'Request evidence must not expose a credential value');
  assert.equal(Object.prototype.propertyIsEnumerable.call(peer, 'token'), false);
  assert.equal(peer.snapshot().credentialValuesIncluded, false);
  assert(peer.snapshot().requests.every(row => !Object.hasOwn(row, 'headers') && !Object.hasOwn(row, 'authorization')));
});
