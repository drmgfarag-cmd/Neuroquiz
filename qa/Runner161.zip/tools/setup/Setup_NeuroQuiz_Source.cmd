@echo off
setlocal DisableDelayedExpansion
rem Source/acceptance tools only. The ordinary app installer bundles its runtime.
set "NQ_BOOTSTRAP_NODE="
for /f "delims=" %%N in ('where node.exe 2^>nul ^| findstr /I /L /V /C:"Microsoft\WindowsApps"') do if not defined NQ_BOOTSTRAP_NODE set "NQ_BOOTSTRAP_NODE=%%N"
if not defined NQ_BOOTSTRAP_NODE goto need_node
"%NQ_BOOTSTRAP_NODE%" -e "let v=process.versions.node.split('.').map(Number);process.exit(process.arch==='x64'&&(v[0]>22||(v[0]===22&&v[1]>=12))?0:1)" >nul 2>nul
if not errorlevel 1 goto run_doctor
:need_node
rem Check-only must not create folders or fetch a bootstrap executable.
for %%A in (%*) do if /I "%%~A"=="--check-only" goto missing_check_only
where curl.exe >nul 2>nul
if errorlevel 1 goto missing_windows_tool
where certutil.exe >nul 2>nul
if errorlevel 1 goto missing_windows_tool
if not defined LOCALAPPDATA goto failed
set "NQ_BOOTSTRAP_ROOT=%LOCALAPPDATA%\NeuroQuiz\SourceTools"
if not exist "%NQ_BOOTSTRAP_ROOT%" mkdir "%NQ_BOOTSTRAP_ROOT%"
if not exist "%NQ_BOOTSTRAP_ROOT%" goto failed
if exist "%NQ_BOOTSTRAP_ROOT%\.neuroquiz-source-tools" goto check_owner
for /f "delims=" %%F in ('dir /b /a "%NQ_BOOTSTRAP_ROOT%" 2^>nul') do goto unknown_owner
>"%NQ_BOOTSTRAP_ROOT%\.neuroquiz-source-tools" echo NeuroQuizSourceTools161
:check_owner
certutil.exe -hashfile "%NQ_BOOTSTRAP_ROOT%\.neuroquiz-source-tools" SHA256 2>nul | findstr /I /X /C:"9583537bfed88121284bd7f79350f509241f668132551670bde50b30e8f7e3c9" /C:"36f2ddf21c919ea38df2fa091dc066772c4b817501b6e2cd749bc17e73514d1e" /C:"5deeb8fd5fde321ecd343ffc537a1c552dc42691268bae4439488534ea0e9538" >nul
if errorlevel 1 goto unknown_owner
set "NQ_BOOTSTRAP_NODE=%NQ_BOOTSTRAP_ROOT%\node-d702daa815eabbff.exe"
if not exist "%NQ_BOOTSTRAP_NODE%" goto download_node
certutil.exe -hashfile "%NQ_BOOTSTRAP_NODE%" SHA256 2>nul | findstr /I /X /C:"d702daa815eabbff763c7d3808e235cf031cf2ca70211b56847bc72f51e240e5" >nul
if not errorlevel 1 goto run_doctor
rem Preserve a modified cache entry; choose a new file rather than overwrite it.
set "NQ_BOOTSTRAP_NODE=%NQ_BOOTSTRAP_ROOT%\node-d702daa815eabbff-%RANDOM%-%RANDOM%.exe"
:download_node
if exist "%NQ_BOOTSTRAP_NODE%.partial" set "NQ_BOOTSTRAP_NODE=%NQ_BOOTSTRAP_ROOT%\node-d702daa815eabbff-%RANDOM%-%RANDOM%.exe"
if exist "%NQ_BOOTSTRAP_NODE%" goto failed
if exist "%NQ_BOOTSTRAP_NODE%.partial" goto failed
curl.exe --fail --proto "=https" --tlsv1.2 --max-redirs 0 --connect-timeout 20 --max-time 180 --max-filesize 134217728 --output "%NQ_BOOTSTRAP_NODE%.partial" "https://nodejs.org/dist/v24.22.1/win-x64/node.exe"
if errorlevel 1 goto failed
certutil.exe -hashfile "%NQ_BOOTSTRAP_NODE%.partial" SHA256 2>nul | findstr /I /X /C:"d702daa815eabbff763c7d3808e235cf031cf2ca70211b56847bc72f51e240e5" >nul
if errorlevel 1 goto failed
move "%NQ_BOOTSTRAP_NODE%.partial" "%NQ_BOOTSTRAP_NODE%" >nul
if errorlevel 1 goto failed
:run_doctor
"%NQ_BOOTSTRAP_NODE%" "%~dp0dependency-doctor.cjs" %*
exit /b %errorlevel%
:missing_check_only
echo The required source Node runtime is missing. No download or folder was created. 1>&2
exit /b 1
:missing_windows_tool
echo Source setup needs the built-in Windows curl.exe and certutil.exe. The ordinary NeuroQuiz app does not need this source setup. 1>&2
exit /b 1
:unknown_owner
echo The source-tools folder has an unknown owner. It was preserved without installing files. 1>&2
exit /b 1
:failed
echo Source setup did not complete. No unverified tool was executed. Keep any partial download for diagnosis and use the ordinary app installer to run NeuroQuiz. 1>&2
exit /b 1
