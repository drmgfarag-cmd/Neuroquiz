<# Optional PowerShell wrapper. The .cmd entry point works without changing script execution policy. #>
[CmdletBinding()]
param([switch]$CheckOnly,[switch]$NodeOnly,[switch]$InstallLockedPackages,[string]$PackageDirectory,[string]$ExpectedLockSha256,[string]$ReportPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$arguments = @()
if ($CheckOnly) { $arguments += '--check-only' }
if ($NodeOnly) { $arguments += '--node-only' }
if ($InstallLockedPackages) { $arguments += '--install-locked-packages' }
if ($PackageDirectory) { $arguments += @('--package-dir', $PackageDirectory) }
if ($ExpectedLockSha256) { $arguments += @('--expected-lock-sha256', $ExpectedLockSha256) }
if ($ReportPath) { $arguments += @('--report-path', $ReportPath) }
& (Join-Path $PSScriptRoot 'Setup_NeuroQuiz_Source.cmd') @arguments
exit $LASTEXITCODE
