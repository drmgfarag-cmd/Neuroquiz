#!/usr/bin/env node
// Source/acceptance tools only. The installed application bundles its runtime.
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const https = require('node:https');
const zlib = require('node:zlib');
const { spawnSync } = require('node:child_process');
const MAX_DOWNLOAD = 128 * 1024 * 1024, MAX_EXPANDED = 512 * 1024 * 1024;
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const OWNER = 'NeuroQuizSourceTools161';
const inside = (root, file) => file.startsWith(root + path.sep);
async function normalDirectory(file) { const s = await fs.lstat(file); if (!s.isDirectory() || s.isSymbolicLink()) throw Error('A normal source-tools directory is required.'); }
async function ensureRoot(root) {
  try { await normalDirectory(root); } catch (error) { if (error.code !== 'ENOENT') throw error; await fs.mkdir(root, { recursive: true }); }
  const owner = path.join(root, '.neuroquiz-source-tools');
  try { if (!([OWNER, OWNER + '\n', OWNER + '\r\n'].includes(await fs.readFile(owner, 'utf8')))) throw Error('The source-tools folder has an unknown owner.'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; if ((await fs.readdir(root)).length) throw Error('The nonempty source-tools folder has no owner marker.'); await fs.writeFile(owner, OWNER, { flag: 'wx' }); }
  const cache = path.join(root, 'VerifiedDownloads');
  try { await normalDirectory(cache); } catch (error) { if (error.code !== 'ENOENT') throw error; await fs.mkdir(cache); }
  return cache;
}
function validatePin(kind, pin) {
  const wanted = kind === 'node' ? `https://nodejs.org/dist/v${pin.version}/${pin.archiveName}` : `https://www.python.org/ftp/python/${pin.version}/${pin.archiveName}`;
  if (!['node', 'python'].includes(kind) || !/^\d+\.\d+\.\d+$/.test(pin.version) || pin.url !== wanted || !/^[a-f0-9]{64}$/.test(pin.sha256) || pin.archiveName.includes('/') || pin.prefix !== (kind === 'node' ? `node-v${pin.version}-win-x64/` : '') || pin.executable !== (kind === 'node' ? 'node.exe' : 'python.exe')) throw Error('Invalid official source-tool pin.');
}
function download(url, destination, { timeoutMs = 180000, maxBytes = MAX_DOWNLOAD } = {}) {
  return new Promise((resolve, reject) => {
    let settled = false, timer;
    const finish = (error) => { if (settled) return; settled = true; clearTimeout(timer); error ? reject(error) : resolve(); };
    const request = https.get(url, { timeout: timeoutMs }, response => {
      if (response.statusCode !== 200 || Number(response.headers['content-length'] || 0) > maxBytes) { finish(Error('Official download refused its status/size bound. No redirect was followed.')); response.destroy(); request.destroy(); return; }
      let bytes = 0, chunks = [];
      response.setTimeout(timeoutMs, () => response.destroy(Error('Official download body timed out.')));
      response.on('data', chunk => { bytes += chunk.length; if (bytes > maxBytes) response.destroy(Error('Official download exceeded its size bound.')); else chunks.push(chunk); });
      response.on('error', finish);
      response.on('end', async () => { if (settled) return; try { await fs.writeFile(destination, Buffer.concat(chunks), { flag: 'wx' }); finish(); } catch (error) { finish(error); } });
    });
    timer = setTimeout(() => { const error = Error('Official tool transfer deadline exceeded.'); finish(error); request.destroy(error); }, timeoutMs);
    request.on('timeout', () => request.destroy(Error('Official tool download timed out.'))); request.on('error', finish);
  });
}
function crc32(buffer) { let crc = 0xffffffff; for (const b of buffer) { crc ^= b; for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0); } return (crc ^ 0xffffffff) >>> 0; }
function archiveFiles(bytes, pin) {
  if (bytes.length > MAX_DOWNLOAD || sha(bytes) !== pin.sha256) throw Error('The tool archive failed its pinned SHA-256 check.');
  let end = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (bytes.readUInt32LE(i) === 0x06054b50 && i + 22 + bytes.readUInt16LE(i + 20) === bytes.length) { end = i; break; }
  if (end < 0 || bytes.readUInt16LE(end + 4) || bytes.readUInt16LE(end + 6)) throw Error('A single normal ZIP archive is required.');
  const count = bytes.readUInt16LE(end + 10), length = bytes.readUInt32LE(end + 12), offset = bytes.readUInt32LE(end + 16);
  if (count > 20000 || count !== bytes.readUInt16LE(end + 8) || offset + length !== end) throw Error('Invalid tool ZIP directory.');
  const seen = new Set(), files = new Map(); let cursor = offset, expanded = 0;
  for (let n = 0; n < count; n++) {
    if (cursor + 46 > end || bytes.readUInt32LE(cursor) !== 0x02014b50) throw Error('Invalid tool ZIP entry.');
    const flags = bytes.readUInt16LE(cursor + 8), method = bytes.readUInt16LE(cursor + 10), crc = bytes.readUInt32LE(cursor + 16), compressed = bytes.readUInt32LE(cursor + 20), size = bytes.readUInt32LE(cursor + 24), names = bytes.readUInt16LE(cursor + 28), extra = bytes.readUInt16LE(cursor + 30), comment = bytes.readUInt16LE(cursor + 32), attributes = bytes.readUInt32LE(cursor + 38), local = bytes.readUInt32LE(cursor + 42);
    const name = bytes.subarray(cursor + 46, cursor + 46 + names).toString('utf8'); cursor += 46 + names + extra + comment;
    if (cursor > end || flags & 1 || ![0, 8].includes(method) || (attributes >>> 16 & 0xf000) === 0xa000 || /[\\:\x00-\x1f<>"|?*]/.test(name) || name.startsWith('/') || !name.startsWith(pin.prefix)) throw Error('Unsafe tool ZIP entry.');
    const relative = name.slice(pin.prefix.length), directory = name.endsWith('/'); if (!relative) { if (!directory) throw Error('Invalid tool ZIP root.'); continue; }
    const logical = relative.replace(/\/$/, '');
    if (logical.split('/').some(part => !part || part === '.' || part === '..' || /[ .]$/.test(part) || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(part)) || seen.has(logical.toLowerCase())) throw Error('Windows-ambiguous or duplicate tool ZIP path.');
    seen.add(logical.toLowerCase()); expanded += size; if (expanded > MAX_EXPANDED) throw Error('Expanded tool ZIP exceeds its size bound.');
    if (local + 30 > offset || bytes.readUInt32LE(local) !== 0x04034b50 || bytes.readUInt16LE(local + 8) !== method || bytes.readUInt16LE(local + 6) !== flags) throw Error('Tool ZIP local header mismatch.');
    const localName = bytes.readUInt16LE(local + 26), localExtra = bytes.readUInt16LE(local + 28), start = local + 30 + localName + localExtra;
    if (bytes.subarray(local + 30, local + 30 + localName).toString('utf8') !== name || start + compressed > offset) throw Error('Tool ZIP local path/data mismatch.');
    if (directory) { if (size !== 0) throw Error('A ZIP directory contains data.'); continue; }
    const data = method === 0 ? bytes.subarray(start, start + compressed) : zlib.inflateRawSync(bytes.subarray(start, start + compressed), { maxOutputLength: Math.max(1, size + 1) });
    if (data.length !== size || crc32(data) !== crc) throw Error('Tool ZIP data/CRC mismatch.'); files.set(logical, data);
  }
  if (cursor !== end || !files.has(pin.executable)) throw Error('Incomplete tool ZIP.'); return files;
}
async function treeMatches(root, files) {
  try {
    await normalDirectory(root);
    const expected = new Set([...files.keys(), '.neuroquiz-tool.json']);
    async function visit(folder, prefix = '') { for (const entry of await fs.readdir(folder, { withFileTypes: true })) { const logical = prefix + entry.name; if (entry.isSymbolicLink()) return false; if (entry.isDirectory()) { if (!await visit(path.join(folder, entry.name), logical + '/')) return false; } else if (!entry.isFile() || !expected.delete(logical)) return false; } return true; }
    if (!await visit(root) || expected.size) return false;
    for (const [name, value] of files) if (sha(await fs.readFile(path.join(root, ...name.split('/')))) !== sha(value)) return false;
    return true;
  } catch { return false; }
}
async function prepareTool(kind, pin, { root, checkOnly = false, fetch = download, platform = process.platform } = {}) {
  validatePin(kind, pin);
  const cache = path.join(root, 'VerifiedDownloads'), archive = path.join(cache, pin.sha256 + '.zip'); let bytes, fetched = false;
  try { const info = await fs.lstat(archive); if (!info.isFile() || info.isSymbolicLink() || info.size <= 0 || info.size > MAX_DOWNLOAD) throw Error('Unsafe or oversized cached tool archive.'); bytes = await fs.readFile(archive); }
  catch (error) { if (error.code !== 'ENOENT') throw error; if (checkOnly) return null; if (platform !== 'win32') throw Error('Automatic portable source-tool installation is for Windows only.'); await ensureRoot(root); const temporary = path.join(cache, 'download-' + crypto.randomUUID() + '.partial'); await fetch(pin.url, temporary); bytes = await fs.readFile(temporary); if (bytes.length > MAX_DOWNLOAD || sha(bytes) !== pin.sha256) throw Error('The downloaded tool failed its pinned SHA-256 check; no executable was run.'); await fs.rename(temporary, archive); fetched = true; }
  const files = archiveFiles(bytes, pin), target = path.join(root, `${kind}-${pin.version}`);
  if (await treeMatches(target, files)) return { exe: path.join(target, pin.executable), version: pin.version, source: 'verified-portable-cache', npmCli: kind === 'node' ? path.join(target, 'node_modules/npm/bin/npm-cli.js') : undefined, downloaded: fetched, installed: false };
  if (checkOnly) return null; if (platform !== 'win32') throw Error('Automatic portable source-tool installation is for Windows only.'); await ensureRoot(root);
  const stage = await fs.mkdtemp(path.join(root, 'stage-'));
  for (const [name, data] of files) { const file = path.join(stage, ...name.split('/')); if (!inside(stage, file)) throw Error('Tool file escaped its private stage.'); await fs.mkdir(path.dirname(file), { recursive: true }); await fs.writeFile(file, data, { flag: 'wx' }); }
  await fs.writeFile(path.join(stage, '.neuroquiz-tool.json'), JSON.stringify({ kind, version: pin.version, archiveSha256: pin.sha256 }), { flag: 'wx' });
  if (!await treeMatches(stage, files)) throw Error('Staged source-tool verification failed.');
  try { await fs.lstat(target); throw Error('A changed existing source-tool directory was preserved. Use another clean source-tools directory; it was not overwritten.'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  await fs.rename(stage, target);
  return { exe: path.join(target, pin.executable), version: pin.version, source: 'verified-portable', npmCli: kind === 'node' ? path.join(target, 'node_modules/npm/bin/npm-cli.js') : undefined, downloaded: fetched, installed: true };
}
function probe(exe, args) { try { const r = spawnSync(exe, args, { encoding: 'utf8', timeout: 10000, windowsHide: true }); return r.status === 0 ? r.stdout.trim() : null; } catch { return null; } }
function existingNode() {
  const version = process.versions.node.split('.').map(Number);
  if (process.arch !== 'x64' || version[0] < 22 || version[0] === 22 && version[1] < 12) return null;
  const candidates = [path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js'), path.resolve(path.dirname(process.execPath), '../lib/node_modules/npm/bin/npm-cli.js')];
  for (const npmCli of candidates) if (probe(process.execPath, [npmCli, '--version'])) return { exe: process.execPath, npmCli, version: process.versions.node, source: 'existing' };
  return null;
}
async function lockedPackages(node, folder, expectedLock, projectRoot) {
  if (!/^[a-f0-9]{64}$/i.test(expectedLock || '')) throw Error('An expected package-lock SHA-256 is required.');
  folder = await fs.realpath(folder); projectRoot = await fs.realpath(projectRoot); if (!inside(projectRoot, folder)) throw Error('Package directory must be inside this continuation.');
  const lock = await fs.readFile(path.join(folder, 'package-lock.json')); if (sha(lock) !== expectedLock.toLowerCase()) throw Error('The package lock changed; no package install was started.');
  const parsed = JSON.parse(lock); if (parsed.lockfileVersion !== 3 || !parsed.packages) throw Error('A reviewed v3 package lock is required.');
  const localTargets = new Set();
  for (const item of Object.values(parsed.packages)) if (item.link) {
    const resolved = await fs.realpath(path.resolve(folder, item.resolved));
    if (!inside(projectRoot, resolved)) throw Error('A local package escapes the continuation.');
    localTargets.add(path.relative(folder, resolved).split(path.sep).join('/'));
  }
  for (const [name, item] of Object.entries(parsed.packages)) {
    if (!name || item.link) continue;
    if (localTargets.has(name) && !item.resolved) {
      const resolved = await fs.realpath(path.join(folder, name));
      if (!inside(projectRoot, resolved)) throw Error('A local package escapes the continuation.');
      const own = JSON.parse(await fs.readFile(path.join(resolved, 'package.json'), 'utf8'));
      if (own.version !== item.version) throw Error('An owned local package version changed.');
      continue;
    }
    const url = new URL(item.resolved);
    if (url.protocol !== 'https:' || url.hostname !== 'registry.npmjs.org' || url.username || url.password || !/^sha512-[A-Za-z0-9+/]+=*$/.test(item.integrity || '')) throw Error('A package is not pinned to the approved npm registry.');
  }
  const result = spawnSync(node.exe, [node.npmCli, 'ci', '--ignore-scripts', '--no-audit', '--fund=false', '--prefix', folder], { stdio: 'inherit', windowsHide: true, timeout: 300000, env: { ...process.env, npm_config_fetch_timeout: '60000', npm_config_fetch_retries: '0', PATH: path.dirname(node.exe) + path.delimiter + process.env.PATH, PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD: '1' } });
  if (result.status !== 0) throw Error('The locked acceptance packages could not be installed.'); return { lockSha256: sha(lock), installed: true, browserDownload: false, lifecycleScripts: false };
}
async function main(argv) {
  const flags = new Set(['--check-only', '--node-only', '--install-locked-packages']); const options = {};
  for (let i = 0; i < argv.length; i++) { const name = argv[i]; if (flags.has(name)) options[name] = true; else if (['--report-path', '--package-dir', '--expected-lock-sha256'].includes(name) && argv[i + 1]) options[name] = argv[++i]; else throw Error('Unknown or incomplete dependency-setup option.'); }
  const pins = JSON.parse(await fs.readFile(path.join(__dirname, 'Dependency_Downloads161.json'), 'utf8'));
  const root = path.join(process.env.LOCALAPPDATA || require('node:os').tmpdir(), 'NeuroQuiz', 'SourceTools');
  const report = { format: 'neuroquiz-source-setup161-v1', purpose: 'maintainer-and-acceptance-only', appRequiresDeveloperTools: false, checkOnly: !!options['--check-only'], node: existingNode(), python: null, succeeded: false, error: null, fullWindowsAcceptance: false };
  try {
    if (!report.node) report.node = await prepareTool('node', pins.node, { root, checkOnly: report.checkOnly });
    if (!report.node) throw Error('Node/npm is missing; run the source setup without --check-only.');
    if (probe(report.node.exe, ['-p', 'process.versions.node']) !== report.node.version || probe(report.node.exe, ['-p', 'process.arch']) !== 'x64' || !probe(report.node.exe, [report.node.npmCli, '--version'])) throw Error('The prepared Node/npm tool could not run its version check.');
    if (!options['--node-only']) {
      for (const command of process.platform === 'win32' ? ['python.exe'] : ['python3', 'python']) {
        for (const directory of (process.env.PATH || '').split(path.delimiter)) {
          const exe = path.join(directory.replace(/^"|"$/g, ''), command);
          if (/\\Microsoft\\WindowsApps\\/i.test(exe)) continue;
          try { if (!(await fs.stat(exe)).isFile()) continue; } catch { continue; }
          const version = probe(exe, ['-c', 'import sys, struct; print("%d.%d.%d" % sys.version_info[:3] if sys.version_info >= (3,11) and struct.calcsize("P")==8 else "unsupported")']);
          if (/^3\.(1[1-9]|[2-9]\d)\.\d+$/.test(version || '')) { report.python = { exe, version, source: 'existing' }; break; }
        }
        if (report.python) break;
      }
      if (!report.python) report.python = await prepareTool('python', pins.python, { root, checkOnly: report.checkOnly });
      if (!report.python) throw Error('Python3.11+ is missing; run source setup without --check-only.');
      if (probe(report.python.exe, ['-c', 'import sys, struct; print("%d.%d.%d" % sys.version_info[:3] if struct.calcsize("P")==8 else "unsupported")']) !== report.python.version) throw Error('The prepared Python tool could not run its version check.');
    }
    if (options['--install-locked-packages']) { if (report.checkOnly) throw Error('Check-only cannot install package dependencies.'); report.lockedPackages = await lockedPackages(report.node, options['--package-dir'], options['--expected-lock-sha256'], path.resolve(__dirname, '../..')); }
    report.succeeded = true;
  } catch (error) { report.error = error.message; }
  const json = JSON.stringify(report, null, 2) + '\n'; if (options['--report-path']) await fs.writeFile(path.resolve(options['--report-path']), json, { flag: 'wx' }); process.stdout.write(json); return report.succeeded ? 0 : 1;
}
module.exports = { sha, archiveFiles, prepareTool, treeMatches, validatePin, download, main };
if (require.main === module) main(process.argv.slice(2)).then(code => { process.exitCode = code; }, error => { process.stderr.write(error.message + '\n'); process.exitCode = 1; });
